package com.campusfix.dao;

import com.campusfix.model.Feedback;
import com.campusfix.util.DBConnection;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Repository
public class FeedbackDAO {

    public FeedbackDAO() {
        // Automatically ensure feedback table exists in MySQL
        ensureTableExists();
    }

    private void ensureTableExists() {
        String createSql = "CREATE TABLE IF NOT EXISTS feedback (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "complaint_id INT NOT NULL, " +
                "student_id INT NOT NULL, " +
                "rating INT NOT NULL, " +
                "comments TEXT, " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                ")";

        try (Connection connection = DBConnection.getConnection();
             Statement stmt = connection.createStatement()) {
            stmt.execute(createSql);
        } catch (Exception e) {
            // Ignore if already created or connection not ready at init
        }
    }

    public boolean addFeedback(int complaintId, int studentId, int rating, String comments) {
        String sql = "INSERT INTO feedback (complaint_id, student_id, rating, comments) VALUES (?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, complaintId);
            statement.setInt(2, studentId);
            statement.setInt(3, rating);
            statement.setString(4, comments);

            return statement.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Feedback getFeedbackByComplaintId(int complaintId) {
        String sql = "SELECT * FROM feedback WHERE complaint_id = ? ORDER BY created_at DESC LIMIT 1";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, complaintId);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                Feedback fb = new Feedback();
                fb.setId(rs.getInt("id"));
                fb.setComplaintId(rs.getInt("complaint_id"));
                fb.setStudentId(rs.getInt("student_id"));
                fb.setRating(rs.getInt("rating"));
                fb.setComments(rs.getString("comments"));
                fb.setCreatedAt(rs.getTimestamp("created_at"));
                return fb;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public double getAverageRating() {
        String sql = "SELECT AVG(rating) as avg_rating FROM feedback";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            if (rs.next()) {
                double avg = rs.getDouble("avg_rating");
                return Math.round(avg * 10.0) / 10.0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    public List<Feedback> getAllFeedback() {
        List<Feedback> list = new ArrayList<>();
        String sql = "SELECT * FROM feedback ORDER BY created_at DESC";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                Feedback fb = new Feedback();
                fb.setId(rs.getInt("id"));
                fb.setComplaintId(rs.getInt("complaint_id"));
                fb.setStudentId(rs.getInt("student_id"));
                fb.setRating(rs.getInt("rating"));
                fb.setComments(rs.getString("comments"));
                fb.setCreatedAt(rs.getTimestamp("created_at"));
                list.add(fb);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
