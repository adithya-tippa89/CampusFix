package com.campusfix.dao;

import com.campusfix.model.Staff;
import com.campusfix.util.DBConnection;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UserDAO {

    // ==============================
    // LOGIN
    // ==============================
    public boolean validateUser(
            String email,
            String password,
            String role) {

        String sql =
                "SELECT * FROM users " +
                        "WHERE email = ? " +
                        "AND password = ? " +
                        "AND role = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(1, email);
            statement.setString(2, password);
            statement.setString(3, role);

            ResultSet resultSet =
                    statement.executeQuery();

            return resultSet.next();

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==============================
    // CHECK EMAIL
    // ==============================
    public boolean emailExists(String email) {

        String sql =
                "SELECT id FROM users WHERE email = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(1, email);

            ResultSet resultSet =
                    statement.executeQuery();

            return resultSet.next();

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==============================
    // REGISTER USER
    // ==============================
    public boolean registerUser(
            String name,
            String email,
            String password,
            String role) {

        String sql =
                "INSERT INTO users " +
                        "(name, email, password, role) " +
                        "VALUES (?, ?, ?, ?)";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, password);
            statement.setString(4, role);

            int rows =
                    statement.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==============================
    // GET USER ID BY EMAIL
    // ==============================
    public int getUserId(String email) {

        String sql =
                "SELECT id FROM users WHERE email = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(1, email);

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return resultSet.getInt("id");
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return -1;
    }


    // ==============================
    // GET ALL STAFF
    // ==============================
    public List<Staff> getAllStaff() {

        List<Staff> staffList =
                new ArrayList<>();

        String sql =
                "SELECT id, name, email " +
                        "FROM users " +
                        "WHERE role = 'STAFF'";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            while (resultSet.next()) {

                Staff staff =
                        new Staff();

                staff.setId(
                        resultSet.getInt("id")
                );

                staff.setName(
                        resultSet.getString("name")
                );

                staff.setEmail(
                        resultSet.getString("email")
                );

                staffList.add(staff);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return staffList;
    }

}
