package com.campusfix.dao;

import com.campusfix.util.DBConnection;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ComplaintDAO {

    public ComplaintDAO() {
        ensureTableExists();
    }

    private void ensureTableExists() {
        String sql = "CREATE TABLE IF NOT EXISTS complaints (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "student_id INT NOT NULL, " +
                "title VARCHAR(255) NOT NULL, " +
                "description TEXT NOT NULL, " +
                "category VARCHAR(100) NOT NULL, " +
                "location VARCHAR(255) NOT NULL, " +
                "priority VARCHAR(50) DEFAULT 'MEDIUM', " +
                "status VARCHAR(50) DEFAULT 'PENDING', " +
                "assigned_to INT DEFAULT NULL, " +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                ")";
        try (Connection con = DBConnection.getConnection();
             Statement stmt = con.createStatement()) {
            stmt.execute(sql);
        } catch (Exception e) {
            // Ignore if connection not ready
        }
    }

    // ==============================
    // ADD COMPLAINT
    // ==============================

    public boolean addComplaint(
            int studentId,
            String title,
            String description,
            String category,
            String location,
            String priority) {

        String sql =
                "INSERT INTO complaints " +
                        "(student_id, title, description, category, " +
                        "location, priority, status) " +
                        "VALUES (?, ?, ?, ?, ?, ?, 'PENDING')";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, studentId);
            statement.setString(2, title);
            statement.setString(3, description);
            statement.setString(4, category);
            statement.setString(5, location);
            statement.setString(6, priority);

            int rows =
                    statement.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==============================
    // GET STUDENT COMPLAINTS
    // ==============================

    public List<com.campusfix.model.Complaint> getComplaintsByStudent(
            int studentId) {

        List<com.campusfix.model.Complaint> complaints =
                new ArrayList<>();

        String sql =
                "SELECT * FROM complaints " +
                        "WHERE student_id = ? " +
                        "ORDER BY created_at DESC";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, studentId);

            ResultSet resultSet =
                    statement.executeQuery();

            while (resultSet.next()) {

                com.campusfix.model.Complaint complaint =
                        new com.campusfix.model.Complaint();

                complaint.setId(
                        resultSet.getInt("id")
                );

                complaint.setStudentId(
                        resultSet.getInt("student_id")
                );

                complaint.setTitle(
                        resultSet.getString("title")
                );

                complaint.setDescription(
                        resultSet.getString("description")
                );

                complaint.setCategory(
                        resultSet.getString("category")
                );

                complaint.setLocation(
                        resultSet.getString("location")
                );

                complaint.setPriority(
                        resultSet.getString("priority")
                );

                complaint.setStatus(
                        resultSet.getString("status")
                );

                // NEW
                complaint.setAssignedTo(
                        resultSet.getInt("assigned_to")
                );

                complaint.setCreatedAt(
                        resultSet.getTimestamp("created_at")
                );

                complaints.add(complaint);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return complaints;
    }


    // ==============================
    // GET ALL COMPLAINTS
    // ==============================

    public List<com.campusfix.model.Complaint> getAllComplaints() {

        List<com.campusfix.model.Complaint> complaints =
                new ArrayList<>();

        String sql =
                "SELECT * FROM complaints " +
                        "ORDER BY created_at DESC";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            while (resultSet.next()) {

                com.campusfix.model.Complaint complaint =
                        new com.campusfix.model.Complaint();

                complaint.setId(
                        resultSet.getInt("id")
                );

                complaint.setStudentId(
                        resultSet.getInt("student_id")
                );

                complaint.setTitle(
                        resultSet.getString("title")
                );

                complaint.setDescription(
                        resultSet.getString("description")
                );

                complaint.setCategory(
                        resultSet.getString("category")
                );

                complaint.setLocation(
                        resultSet.getString("location")
                );

                complaint.setPriority(
                        resultSet.getString("priority")
                );

                complaint.setStatus(
                        resultSet.getString("status")
                );

                // NEW
                complaint.setAssignedTo(
                        resultSet.getInt("assigned_to")
                );

                complaint.setCreatedAt(
                        resultSet.getTimestamp("created_at")
                );

                complaints.add(complaint);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return complaints;
    }


    // ==============================
    // GET COMPLAINT BY ID
    // ==============================

    public com.campusfix.model.Complaint getComplaintById(
            int complaintId) {

        String sql =
                "SELECT * FROM complaints WHERE id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, complaintId);

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                com.campusfix.model.Complaint complaint =
                        new com.campusfix.model.Complaint();

                complaint.setId(
                        resultSet.getInt("id")
                );

                complaint.setStudentId(
                        resultSet.getInt("student_id")
                );

                complaint.setTitle(
                        resultSet.getString("title")
                );

                complaint.setDescription(
                        resultSet.getString("description")
                );

                complaint.setCategory(
                        resultSet.getString("category")
                );

                complaint.setLocation(
                        resultSet.getString("location")
                );

                complaint.setPriority(
                        resultSet.getString("priority")
                );

                complaint.setStatus(
                        resultSet.getString("status")
                );

                // NEW
                complaint.setAssignedTo(
                        resultSet.getInt("assigned_to")
                );

                complaint.setCreatedAt(
                        resultSet.getTimestamp("created_at")
                );

                return complaint;
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return null;
    }


    // ==============================
    // ASSIGN COMPLAINT TO STAFF
    // ==============================

    public boolean assignComplaint(
            int complaintId,
            int staffId) {

        String sql =
                "UPDATE complaints " +
                        "SET assigned_to = ?, " +
                        "status = 'ASSIGNED' " +
                        "WHERE id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, staffId);
            statement.setInt(2, complaintId);

            int rows =
                    statement.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==================================================
    // NEW METHOD 1
    // GET COMPLAINTS ASSIGNED TO PARTICULAR STAFF
    // ==================================================

    public List<com.campusfix.model.Complaint> getComplaintsByStaff(
            int staffId) {

        List<com.campusfix.model.Complaint> complaints =
                new ArrayList<>();

        String sql =
                "SELECT * FROM complaints " +
                        "WHERE assigned_to = ? " +
                        "ORDER BY created_at DESC";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, staffId);

            ResultSet resultSet =
                    statement.executeQuery();

            while (resultSet.next()) {

                com.campusfix.model.Complaint complaint =
                        new com.campusfix.model.Complaint();

                complaint.setId(
                        resultSet.getInt("id")
                );

                complaint.setStudentId(
                        resultSet.getInt("student_id")
                );

                complaint.setTitle(
                        resultSet.getString("title")
                );

                complaint.setDescription(
                        resultSet.getString("description")
                );

                complaint.setCategory(
                        resultSet.getString("category")
                );

                complaint.setLocation(
                        resultSet.getString("location")
                );

                complaint.setPriority(
                        resultSet.getString("priority")
                );

                complaint.setStatus(
                        resultSet.getString("status")
                );

                complaint.setAssignedTo(
                        resultSet.getInt("assigned_to")
                );

                complaint.setCreatedAt(
                        resultSet.getTimestamp("created_at")
                );

                complaints.add(complaint);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return complaints;
    }


    // ==================================================
    // NEW METHOD 2
    // UPDATE COMPLAINT STATUS
    // ==================================================

    public boolean updateStatus(
            int complaintId,
            int staffId,
            String status) {

        String sql =
                "UPDATE complaints " +
                        "SET status = ? " +
                        "WHERE id = ? " +
                        "AND assigned_to = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(1, status);
            statement.setInt(2, complaintId);
            statement.setInt(3, staffId);

            int rows =
                    statement.executeUpdate();

            return rows > 0;

        } catch (Exception e) {

            e.printStackTrace();

            return false;
        }
    }

}
