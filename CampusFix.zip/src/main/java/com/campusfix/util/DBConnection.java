package com.campusfix.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/campusfix";

    private static final String USER =
            "root";

    private static final String PASSWORD =
            "adi89";


    public static Connection getConnection()
            throws SQLException {

        try {

            System.out.println(
                    "Loading MySQL Driver..."
            );

            Class.forName(
                    "com.mysql.cj.jdbc.Driver"
            );

            System.out.println(
                    "MySQL Driver Loaded Successfully!"
            );

        } catch (ClassNotFoundException e) {

            throw new SQLException(
                    "MySQL JDBC Driver not found!",
                    e
            );
        }

        return DriverManager.getConnection(
                URL,
                USER,
                PASSWORD
        );
    }

}