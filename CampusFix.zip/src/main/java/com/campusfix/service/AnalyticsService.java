package com.campusfix.service;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.FeedbackDAO;
import com.campusfix.model.Complaint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AnalyticsService {

    private final ComplaintDAO complaintDAO;
    private final FeedbackDAO feedbackDAO;

    @Autowired
    public AnalyticsService(ComplaintDAO complaintDAO, FeedbackDAO feedbackDAO) {
        this.complaintDAO = complaintDAO;
        this.feedbackDAO = feedbackDAO;
    }

    public Map<String, Object> getDashboardStats() {
        List<Complaint> complaints = complaintDAO.getAllComplaints();
        Map<String, Object> stats = new HashMap<>();

        int total = complaints.size();
        int pending = 0;
        int assigned = 0;
        int inProgress = 0;
        int resolved = 0;
        int highPriority = 0;

        Map<String, Integer> categoryDistribution = new HashMap<>();

        for (Complaint c : complaints) {
            String s = c.getStatus() != null ? c.getStatus().toUpperCase() : "PENDING";
            if ("PENDING".equals(s)) pending++;
            else if ("ASSIGNED".equals(s)) assigned++;
            else if ("IN_PROGRESS".equals(s)) inProgress++;
            else if ("RESOLVED".equals(s)) resolved++;

            if ("HIGH".equalsIgnoreCase(c.getPriority()) && !"RESOLVED".equals(s)) {
                highPriority++;
            }

            String cat = c.getCategory() != null ? c.getCategory().toUpperCase() : "OTHER";
            categoryDistribution.put(cat, categoryDistribution.getOrDefault(cat, 0) + 1);
        }

        double resolutionRate = total > 0 ? (resolved * 100.0 / total) : 100.0;
        double averageRating = feedbackDAO.getAverageRating();

        stats.put("totalComplaints", total);
        stats.put("pendingComplaints", pending);
        stats.put("assignedComplaints", assigned);
        stats.put("inProgressComplaints", inProgress);
        stats.put("resolvedComplaints", resolved);
        stats.put("highPriorityUrgent", highPriority);
        stats.put("resolutionRatePercent", Math.round(resolutionRate * 10.0) / 10.0);
        stats.put("averageStudentRating", averageRating);
        stats.put("categoryDistribution", categoryDistribution);

        return stats;
    }
}
