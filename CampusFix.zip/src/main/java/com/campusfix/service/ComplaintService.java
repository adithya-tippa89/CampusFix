package com.campusfix.service;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.model.Complaint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ComplaintService {

    private final ComplaintDAO complaintDAO;

    @Autowired
    public ComplaintService(ComplaintDAO complaintDAO) {
        this.complaintDAO = complaintDAO;
    }

    public List<Complaint> getAllComplaints() {
        return complaintDAO.getAllComplaints();
    }

    public List<Complaint> getComplaintsByStudent(int studentId) {
        return complaintDAO.getComplaintsByStudent(studentId);
    }

    public List<Complaint> getComplaintsByStaff(int staffId) {
        return complaintDAO.getComplaintsByStaff(staffId);
    }

    public Complaint getComplaintById(int id) {
        return complaintDAO.getComplaintById(id);
    }

    public boolean addComplaint(int studentId, String title, String description,
                                String category, String location, String priority) {
        if (title == null || title.trim().isEmpty()) {
            return false;
        }
        return complaintDAO.addComplaint(studentId, title, description, category, location, priority);
    }

    public boolean assignComplaint(int complaintId, int staffId) {
        return complaintDAO.assignComplaint(complaintId, staffId);
    }

    public boolean updateStatus(int complaintId, int staffId, String status) {
        return complaintDAO.updateStatus(complaintId, staffId, status);
    }

    /**
     * Future Implementation: Target SLA (Service Level Agreement) in Hours
     */
    public int getTargetSLAHours(String priority) {
        if ("HIGH".equalsIgnoreCase(priority)) {
            return 24; // 24 hours max
        } else if ("MEDIUM".equalsIgnoreCase(priority)) {
            return 48; // 48 hours
        } else {
            return 72; // 72 hours for Low priority
        }
    }
}
