package com.campusfix.service;

import com.campusfix.dao.NotificationDAO;
import com.campusfix.model.Notification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {

    private final NotificationDAO notificationDAO;

    @Autowired
    public NotificationService(NotificationDAO notificationDAO) {
        this.notificationDAO = notificationDAO;
    }

    public void notifyComplaintLodge(int complaintId, int studentId, String title, String priority, String location) {
        // 1. Notify Student
        notificationDAO.addNotification(
                studentId,
                "Ticket Submitted: CF-" + complaintId,
                "Your issue '" + title + "' at " + location + " has been registered and is pending administrator review.",
                "INFO",
                "my-complaints"
        );

        // 2. Notify all Administrators
        notificationDAO.notifyAllAdmins(
                "New " + priority + " Priority Ticket: CF-" + complaintId,
                "A student reported: '" + title + "' at " + location + ". Needs staff assignment.",
                "WARNING",
                "admin-complaint?id=" + complaintId
        );
    }

    public void notifyComplaintAssigned(int complaintId, int staffId, int studentId, String title, String location) {
        // 1. Notify Assigned Staff
        notificationDAO.addNotification(
                staffId,
                "New Work Order Assigned: CF-" + complaintId,
                "You have been assigned to repair: '" + title + "' located at " + location + ".",
                "ASSIGNMENT",
                "staff-complaint?id=" + complaintId
        );

        // 2. Notify Student
        if (studentId > 0) {
            notificationDAO.addNotification(
                    studentId,
                    "Technician Assigned: CF-" + complaintId,
                    "A maintenance staff technician has been assigned to work on '" + title + "'.",
                    "INFO",
                    "my-complaints"
            );
        }
    }

    public void notifyStatusUpdated(int complaintId, int studentId, String title, String status) {
        if ("RESOLVED".equalsIgnoreCase(status)) {
            // Student notification with prompt to rate
            notificationDAO.addNotification(
                    studentId,
                    "Issue Resolved: CF-" + complaintId,
                    "Great news! '" + title + "' has been marked as RESOLVED. Please take a moment to rate the repair service.",
                    "SUCCESS",
                    "my-complaints"
            );

            // Admin notification
            notificationDAO.notifyAllAdmins(
                    "Work Completed: CF-" + complaintId,
                    "Staff has completed and resolved '" + title + "'.",
                    "SUCCESS",
                    "admin-complaint?id=" + complaintId
            );
        } else if ("IN_PROGRESS".equalsIgnoreCase(status)) {
            // Student notification
            notificationDAO.addNotification(
                    studentId,
                    "Work In Progress: CF-" + complaintId,
                    "Maintenance staff has arrived on site and started work on '" + title + "'.",
                    "INFO",
                    "my-complaints"
            );
        }
    }

    public void notifyFeedbackSubmitted(int complaintId, int staffId, int rating) {
        if (staffId > 0) {
            notificationDAO.addNotification(
                    staffId,
                    "Student Feedback: CF-" + complaintId,
                    "The student rated your work order repair with " + rating + " stars! ⭐",
                    "SUCCESS",
                    "staff-complaint?id=" + complaintId
            );
        }
    }

    public List<Notification> getRecentNotifications(int userId, int limit) {
        return notificationDAO.getRecentNotifications(userId, limit);
    }

    public List<Notification> getAllNotifications(int userId) {
        return notificationDAO.getNotificationsByUser(userId);
    }

    public int getUnreadCount(int userId) {
        return notificationDAO.getUnreadCount(userId);
    }

    public int getUnreadCountByEmail(String email) {
        return notificationDAO.getUnreadCountByEmail(email);
    }

    public boolean markAsRead(int notificationId) {
        return notificationDAO.markAsRead(notificationId);
    }

    public boolean markAllAsRead(int userId) {
        return notificationDAO.markAllAsRead(userId);
    }
}
