package com.campusfix.service;

import com.campusfix.dao.UserDAO;
import com.campusfix.model.Staff;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserDAO userDAO;

    @Autowired
    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public boolean validateUser(String email, String password, String role) {
        if (email == null || password == null || role == null) {
            return false;
        }
        return userDAO.validateUser(email.trim(), password.trim(), role.trim());
    }

    public boolean registerUser(String name, String email, String password, String role) {
        if (email == null || emailExists(email)) {
            return false;
        }
        return userDAO.registerUser(name, email, password, role);
    }

    public boolean emailExists(String email) {
        return userDAO.emailExists(email);
    }

    public int getUserId(String email) {
        return userDAO.getUserId(email);
    }

    public List<Staff> getAllStaff() {
        return userDAO.getAllStaff();
    }
}
