package com.campusfix.service;

import com.campusfix.dao.FeedbackDAO;
import com.campusfix.model.Feedback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeedbackService {

    private final FeedbackDAO feedbackDAO;

    @Autowired
    public FeedbackService(FeedbackDAO feedbackDAO) {
        this.feedbackDAO = feedbackDAO;
    }

    public boolean submitFeedback(int complaintId, int studentId, int rating, String comments) {
        if (rating < 1 || rating > 5) {
            rating = 5;
        }
        return feedbackDAO.addFeedback(complaintId, studentId, rating, comments);
    }

    public Feedback getFeedbackByComplaintId(int complaintId) {
        return feedbackDAO.getFeedbackByComplaintId(complaintId);
    }

    public double getAverageRating() {
        return feedbackDAO.getAverageRating();
    }

    public List<Feedback> getAllFeedback() {
        return feedbackDAO.getAllFeedback();
    }
}
