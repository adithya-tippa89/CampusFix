package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.model.Complaint;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin-complaints")
public class AdminComplaintsServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession(false);

        // Admin login check

        if (session == null ||
                session.getAttribute("email") == null ||
                !"ADMIN".equals(
                        session.getAttribute("role"))) {

            response.sendRedirect("login.jsp");

            return;
        }


        // Get all complaints

        ComplaintDAO complaintDAO =
                new ComplaintDAO();

        List<Complaint> complaints =
                complaintDAO.getAllComplaints();


        // Send data to JSP

        request.setAttribute(
                "complaints",
                complaints
        );


        // Open admin complaints page

        request.getRequestDispatcher(
                "admin-complaints.jsp"
        ).forward(request, response);
    }
}