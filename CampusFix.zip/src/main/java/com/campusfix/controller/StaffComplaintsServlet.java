package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.UserDAO;
import com.campusfix.model.Complaint;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/staff-complaints")
public class StaffComplaintsServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession(false);

        // Check staff login

        if (session == null ||
                session.getAttribute("email") == null ||
                !"STAFF".equals(
                        session.getAttribute("role"))) {

            response.sendRedirect("login.jsp");

            return;
        }


        String email =
                (String) session.getAttribute("email");


        // Get staff ID

        UserDAO userDAO =
                new UserDAO();

        int staffId =
                userDAO.getUserId(email);


        if (staffId == -1) {

            response.sendRedirect(
                    "staff-dashboard.jsp"
            );

            return;
        }


        // Get assigned complaints

        ComplaintDAO complaintDAO =
                new ComplaintDAO();

        List<Complaint> complaints =
                complaintDAO.getComplaintsByStaff(
                        staffId
                );


        request.setAttribute(
                "complaints",
                complaints
        );


        request.getRequestDispatcher(
                "staff-complaints.jsp"
        ).forward(request, response);
    }
}