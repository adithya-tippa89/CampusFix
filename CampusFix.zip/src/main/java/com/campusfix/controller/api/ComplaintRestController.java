package com.campusfix.controller.api;

import com.campusfix.model.Complaint;
import com.campusfix.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping({"/complaints", "/api/complaints"})
@CrossOrigin(origins = "*")
public class ComplaintRestController {

    private final ComplaintService complaintService;

    @Autowired
    public ComplaintRestController(ComplaintService complaintService) {
        this.complaintService = complaintService;
    }

    /**
     * GET /api/complaints
     * Returns all complaints in JSON format
     */
    @GetMapping
    public ResponseEntity<List<Complaint>> getAllComplaints() {
        return ResponseEntity.ok(complaintService.getAllComplaints());
    }

    /**
     * GET /api/complaints/{id}
     * Returns a single complaint by its ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> getComplaintById(@PathVariable("id") int id) {
        Complaint complaint = complaintService.getComplaintById(id);
        if (complaint != null) {
            return ResponseEntity.ok(complaint);
        }
        Map<String, String> error = new HashMap<>();
        error.put("error", "Complaint with ID " + id + " not found");
        return ResponseEntity.status(404).body(error);
    }

    /**
     * GET /api/complaints/categories
     * Returns list of supported categories
     */
    @GetMapping("/categories")
    public ResponseEntity<List<String>> getCategories() {
        return ResponseEntity.ok(Arrays.asList(
                "ELECTRICAL", "WIFI", "LAB", "CLASSROOM",
                "HOSTEL", "CLEANING", "WATER", "FURNITURE", "OTHER"
        ));
    }

    /**
     * POST /api/complaints/add
     * Submits a new complaint ticket via JSON
     */
    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addComplaint(@RequestBody Map<String, Object> payload) {
        Map<String, Object> response = new HashMap<>();
        try {
            int studentId = Integer.parseInt(payload.get("studentId").toString());
            String title = (String) payload.get("title");
            String description = (String) payload.get("description");
            String category = (String) payload.get("category");
            String location = (String) payload.get("location");
            String priority = (String) payload.get("priority");

            boolean success = complaintService.addComplaint(studentId, title, description, category, location, priority);
            response.put("success", success);
            response.put("message", success ? "Complaint created successfully" : "Failed to create complaint");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
}
