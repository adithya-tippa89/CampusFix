package com.campusfix.controller.api;

import com.campusfix.model.Feedback;
import com.campusfix.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping({"/feedback", "/api/feedback"})
@CrossOrigin(origins = "*")
public class FeedbackRestController {

    private final FeedbackService feedbackService;

    @Autowired
    public FeedbackRestController(FeedbackService feedbackService) {
        this.feedbackService = feedbackService;
    }

    /**
     * POST /api/feedback/submit
     * Allows students to rate and review maintenance repairs
     */
    @PostMapping("/submit")
    public ResponseEntity<Map<String, Object>> submitFeedback(@RequestBody Map<String, Object> payload) {
        Map<String, Object> response = new HashMap<>();
        try {
            int complaintId = Integer.parseInt(payload.get("complaintId").toString());
            int studentId = Integer.parseInt(payload.get("studentId").toString());
            int rating = Integer.parseInt(payload.get("rating").toString());
            String comments = (String) payload.getOrDefault("comments", "");

            boolean success = feedbackService.submitFeedback(complaintId, studentId, rating, comments);
            response.put("success", success);
            response.put("message", success ? "Thank you! Your feedback has been recorded." : "Failed to record feedback.");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    /**
     * GET /api/feedback/complaint/{complaintId}
     */
    @GetMapping("/complaint/{complaintId}")
    public ResponseEntity<?> getFeedbackByComplaint(@PathVariable("complaintId") int complaintId) {
        Feedback fb = feedbackService.getFeedbackByComplaintId(complaintId);
        if (fb != null) {
            return ResponseEntity.ok(fb);
        }
        Map<String, String> res = new HashMap<>();
        res.put("message", "No feedback yet for complaint #" + complaintId);
        return ResponseEntity.ok(res);
    }

    /**
     * GET /api/feedback/all
     */
    @GetMapping("/all")
    public ResponseEntity<List<Feedback>> getAllFeedback() {
        return ResponseEntity.ok(feedbackService.getAllFeedback());
    }
}
