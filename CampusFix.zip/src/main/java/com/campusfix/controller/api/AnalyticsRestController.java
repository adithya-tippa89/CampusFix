package com.campusfix.controller.api;

import com.campusfix.service.AnalyticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping({"/analytics", "/api/analytics"})
@CrossOrigin(origins = "*")
public class AnalyticsRestController {

    private final AnalyticsService analyticsService;

    @Autowired
    public AnalyticsRestController(AnalyticsService analyticsService) {
        this.analyticsService = analyticsService;
    }

    /**
     * GET /api/analytics/stats
     * Returns comprehensive live statistics for dashboard metrics and visualizations
     */
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getLiveStats() {
        return ResponseEntity.ok(analyticsService.getDashboardStats());
    }
}
