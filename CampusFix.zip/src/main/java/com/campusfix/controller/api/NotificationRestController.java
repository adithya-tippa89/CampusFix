package com.campusfix.controller.api;

import com.campusfix.dao.UserDAO;
import com.campusfix.model.Notification;
import com.campusfix.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping({"/notifications", "/api/notifications"})
@CrossOrigin(origins = "*")
public class NotificationRestController {

    private final NotificationService notificationService;
    private final UserDAO userDAO;

    @Autowired
    public NotificationRestController(NotificationService notificationService, UserDAO userDAO) {
        this.notificationService = notificationService;
        this.userDAO = userDAO;
    }

    private int resolveUserId(HttpSession session, Integer userIdParam) {
        if (userIdParam != null && userIdParam > 0) {
            return userIdParam;
        }
        if (session != null && session.getAttribute("email") != null) {
            String email = (String) session.getAttribute("email");
            return userDAO.getUserId(email);
        }
        return -1;
    }

    /**
     * GET /api/notifications
     * Returns the recent 10 notifications for the current user
     */
    @GetMapping
    public ResponseEntity<List<Notification>> getNotifications(
            HttpSession session,
            @RequestParam(value = "userId", required = false) Integer userIdParam,
            @RequestParam(value = "limit", defaultValue = "10") int limit) {

        int userId = resolveUserId(session, userIdParam);
        if (userId == -1) {
            return ResponseEntity.ok(Collections.emptyList());
        }
        return ResponseEntity.ok(notificationService.getRecentNotifications(userId, limit));
    }

    /**
     * GET /api/notifications/unread-count
     * Returns badge number for the navbar bell icon
     */
    @GetMapping("/unread-count")
    public ResponseEntity<Map<String, Object>> getUnreadCount(
            HttpSession session,
            @RequestParam(value = "userId", required = false) Integer userIdParam) {

        Map<String, Object> res = new HashMap<>();
        int userId = resolveUserId(session, userIdParam);
        if (userId == -1) {
            res.put("unreadCount", 0);
            return ResponseEntity.ok(res);
        }

        int count = notificationService.getUnreadCount(userId);
        res.put("unreadCount", count);
        return ResponseEntity.ok(res);
    }

    /**
     * POST /api/notifications/{id}/read
     */
    @PostMapping("/{id}/read")
    public ResponseEntity<Map<String, Object>> markAsRead(@PathVariable("id") int id) {
        Map<String, Object> res = new HashMap<>();
        boolean success = notificationService.markAsRead(id);
        res.put("success", success);
        return ResponseEntity.ok(res);
    }

    /**
     * POST /api/notifications/read-all
     */
    @PostMapping("/read-all")
    public ResponseEntity<Map<String, Object>> markAllAsRead(
            HttpSession session,
            @RequestParam(value = "userId", required = false) Integer userIdParam) {

        Map<String, Object> res = new HashMap<>();
        int userId = resolveUserId(session, userIdParam);
        if (userId == -1) {
            res.put("success", false);
            return ResponseEntity.badRequest().body(res);
        }

        boolean success = notificationService.markAllAsRead(userId);
        res.put("success", success);
        return ResponseEntity.ok(res);
    }
}
