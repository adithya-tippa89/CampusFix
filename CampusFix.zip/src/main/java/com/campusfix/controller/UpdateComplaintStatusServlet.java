package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.NotificationDAO;
import com.campusfix.dao.UserDAO;
import com.campusfix.model.Complaint;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/update-status")
public class UpdateComplaintStatusServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
                session.getAttribute("email") == null ||
                !"STAFF".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String email = (String) session.getAttribute("email");
        String complaintId = request.getParameter("complaintId");
        String status = request.getParameter("status");

        try {
            int cId = Integer.parseInt(complaintId);

            // Get staff ID
            UserDAO userDAO = new UserDAO();
            int staffId = userDAO.getUserId(email);

            // Validate status
            if (!status.equals("IN_PROGRESS") && !status.equals("RESOLVED")) {
                response.sendRedirect("staff-complaint?id=" + cId);
                return;
            }

            ComplaintDAO complaintDAO = new ComplaintDAO();
            boolean success = complaintDAO.updateStatus(cId, staffId, status);

            if (success) {
                // Trigger Notifications
                NotificationDAO notifDAO = new NotificationDAO();
                Complaint comp = complaintDAO.getComplaintById(cId);
                String title = (comp != null) ? comp.getTitle() : ("Ticket #" + cId);

                if (comp != null && comp.getStudentId() > 0) {
                    if ("RESOLVED".equals(status)) {
                        notifDAO.addNotification(
                                comp.getStudentId(),
                                "Repair Completed: CF-" + cId,
                                "Your reported issue '" + title + "' has been marked as RESOLVED! Please rate the technician's repair work.",
                                "SUCCESS",
                                "my-complaints"
                        );
                        notifDAO.notifyAllAdmins(
                                "Ticket Resolved: CF-" + cId,
                                "Staff resolved '" + title + "' in " + comp.getLocation() + ".",
                                "SUCCESS",
                                "admin-complaint?id=" + cId
                        );
                    } else if ("IN_PROGRESS".equals(status)) {
                        notifDAO.addNotification(
                                comp.getStudentId(),
                                "Technician Working On Site: CF-" + cId,
                                "Maintenance staff is currently on site repairing '" + title + "'.",
                                "INFO",
                                "my-complaints"
                        );
                    }
                }

                response.sendRedirect("staff-complaint?id=" + cId + "&success=true");
            } else {
                response.sendRedirect("staff-complaint?id=" + cId + "&error=true");
            }

        } catch (NumberFormatException e) {
            response.sendRedirect("staff-complaints");
        }
    }
}
