package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.NotificationDAO;
import com.campusfix.model.Complaint;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/assign-complaint")
public class AssignComplaintServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // Admin check
        if (session == null ||
                session.getAttribute("email") == null ||
                !"ADMIN".equals(session.getAttribute("role"))) {
            response.sendRedirect("login.jsp");
            return;
        }

        String complaintId = request.getParameter("complaintId");
        String staffId = request.getParameter("staffId");

        try {
            int cId = Integer.parseInt(complaintId);
            int sId = Integer.parseInt(staffId);

            ComplaintDAO complaintDAO = new ComplaintDAO();
            boolean success = complaintDAO.assignComplaint(cId, sId);

            if (success) {
                // Trigger Notifications
                NotificationDAO notifDAO = new NotificationDAO();
                Complaint comp = complaintDAO.getComplaintById(cId);
                String title = (comp != null) ? comp.getTitle() : ("Ticket #" + cId);
                String loc = (comp != null) ? comp.getLocation() : "Campus";

                // Notify Assigned Staff
                notifDAO.addNotification(
                        sId,
                        "New Work Order: CF-" + cId,
                        "You have been assigned to repair '" + title + "' at " + loc + ".",
                        "ASSIGNMENT",
                        "staff-complaint?id=" + cId
                );

                // Notify Student
                if (comp != null && comp.getStudentId() > 0) {
                    notifDAO.addNotification(
                            comp.getStudentId(),
                            "Technician Assigned: CF-" + cId,
                            "Maintenance staff has been assigned to work on your complaint '" + title + "'.",
                            "INFO",
                            "my-complaints"
                    );
                }

                response.sendRedirect("admin-complaint?id=" + cId + "&success=true");
            } else {
                response.sendRedirect("admin-complaint?id=" + cId + "&error=true");
            }

        } catch (NumberFormatException e) {
            response.sendRedirect("admin-complaints");
        }
    }
}
