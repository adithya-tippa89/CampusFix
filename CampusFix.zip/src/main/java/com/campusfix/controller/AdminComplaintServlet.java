package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.UserDAO;
import com.campusfix.model.Complaint;
import com.campusfix.model.Staff;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin-complaint")
public class AdminComplaintServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession(false);

        // Admin check

        if (session == null ||
                session.getAttribute("email") == null ||
                !"ADMIN".equals(
                        session.getAttribute("role"))) {

            response.sendRedirect("login.jsp");

            return;
        }


        // Get complaint ID

        String id =
                request.getParameter("id");

        if (id == null) {

            response.sendRedirect(
                    "admin-complaints"
            );

            return;
        }


        int complaintId;

        try {

            complaintId =
                    Integer.parseInt(id);

        } catch (NumberFormatException e) {

            response.sendRedirect(
                    "admin-complaints"
            );

            return;
        }


        // Get complaint

        ComplaintDAO complaintDAO =
                new ComplaintDAO();

        Complaint complaint =
                complaintDAO.getComplaintById(
                        complaintId
                );


        if (complaint == null) {

            response.sendRedirect(
                    "admin-complaints"
            );

            return;
        }


        // Get staff list

        UserDAO userDAO =
                new UserDAO();

        List<Staff> staffList =
                userDAO.getAllStaff();


        // Send data to JSP

        request.setAttribute(
                "complaint",
                complaint
        );

        request.setAttribute(
                "staffList",
                staffList
        );


        request.getRequestDispatcher(
                "admin-complaint.jsp"
        ).forward(request, response);
    }
}