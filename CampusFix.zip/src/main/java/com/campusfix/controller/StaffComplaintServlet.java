package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.UserDAO;
import com.campusfix.model.Complaint;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/staff-complaint")
public class StaffComplaintServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // ==============================
        // CHECK STAFF LOGIN
        // ==============================

        HttpSession session =
                request.getSession(false);

        if (session == null ||
                session.getAttribute("email") == null ||
                !"STAFF".equals(
                        session.getAttribute("role"))) {

            response.sendRedirect("login.jsp");

            return;
        }


        // ==============================
        // GET STAFF EMAIL
        // ==============================

        String email =
                (String) session.getAttribute("email");


        // ==============================
        // GET COMPLAINT ID
        // ==============================

        String id =
                request.getParameter("id");


        if (id == null) {

            response.sendRedirect(
                    "staff-complaints"
            );

            return;
        }


        try {

            int complaintId =
                    Integer.parseInt(id);


            // ==============================
            // GET STAFF ID
            // ==============================

            UserDAO userDAO =
                    new UserDAO();

            int staffId =
                    userDAO.getUserId(email);


            // Staff not found

            if (staffId == -1) {

                response.sendRedirect(
                        "staff-complaints"
                );

                return;
            }


            // ==============================
            // GET COMPLAINT
            // ==============================

            ComplaintDAO complaintDAO =
                    new ComplaintDAO();

            Complaint complaint =
                    complaintDAO.getComplaintById(
                            complaintId
                    );


            // ==============================
            // CHECK COMPLAINT EXISTS
            // ==============================

            if (complaint == null) {

                response.sendRedirect(
                        "staff-complaints"
                );

                return;
            }


            // ==============================
            // SECURITY CHECK
            // ==============================
            // Only assigned staff can view
            // this complaint.

            if (complaint.getAssignedTo()
                    != staffId) {

                response.sendRedirect(
                        "staff-complaints"
                );

                return;
            }


            // ==============================
            // SEND DATA TO JSP
            // ==============================

            request.setAttribute(
                    "complaint",
                    complaint
            );


            request.setAttribute(
                    "staffId",
                    staffId
            );


            // ==============================
            // OPEN STAFF COMPLAINT PAGE
            // ==============================

            request.getRequestDispatcher(
                    "staff-complaint.jsp"
            ).forward(request, response);


        } catch (NumberFormatException e) {

            response.sendRedirect(
                    "staff-complaints"
            );
        }
    }
}