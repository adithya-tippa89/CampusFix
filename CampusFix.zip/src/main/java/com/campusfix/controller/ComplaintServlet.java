package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.NotificationDAO;
import com.campusfix.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import java.io.IOException;
import java.nio.file.Paths;

@WebServlet("/complaint")
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024,      // 1 MB
        maxFileSize = 1024 * 1024 * 10,       // 10 MB
        maxRequestSize = 1024 * 1024 * 25     // 25 MB
)
public class ComplaintServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("complaint.jsp");
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // UTF-8 encoding
        request.setCharacterEncoding("UTF-8");

        // Get logged-in session
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Get email from session
        String email = (String) session.getAttribute("email");

        // Get form data
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String category = request.getParameter("category");
        String location = request.getParameter("location");
        String priority = request.getParameter("priority");
        String contactPhone = request.getParameter("contactPhone");

        // Validate required fields
        if (title == null || title.trim().isEmpty() || location == null || location.trim().isEmpty()) {
            response.sendRedirect("complaint.jsp?error=true");
            return;
        }

        title = title.trim();
        location = location.trim();

        if (description == null || description.trim().isEmpty()) {
            description = title;
        } else {
            description = description.trim();
        }

        if (category == null || category.trim().isEmpty()) {
            category = "ELECTRICAL";
        } else {
            category = category.trim().toUpperCase();
        }

        if (priority == null || priority.trim().isEmpty()) {
            priority = "MEDIUM";
        } else {
            priority = priority.trim().toUpperCase();
        }

        // Append optional contact phone if provided
        if (contactPhone != null && !contactPhone.trim().isEmpty()) {
            description = description + "\n\n📞 Student Contact: " + contactPhone.trim();
        }

        // Capture attached photo filename if provided
        try {
            Part photoPart = request.getPart("photoFile");
            if (photoPart != null && photoPart.getSize() > 0) {
                String submittedName = photoPart.getSubmittedFileName();
                if (submittedName != null && !submittedName.trim().isEmpty()) {
                    String cleanName = Paths.get(submittedName).getFileName().toString();
                    description = description + "\n\n📷 Photo Attached: " + cleanName;
                }
            }
        } catch (Exception ignored) {
            // Optional file attachment, safe to ignore
        }

        // Get student ID
        UserDAO userDAO = new UserDAO();
        int studentId = userDAO.getUserId(email != null ? email.trim() : "");

        if (studentId == -1) {
            response.sendRedirect("complaint.jsp?error=true");
            return;
        }

        // Save complaint
        ComplaintDAO complaintDAO = new ComplaintDAO();
        boolean success = complaintDAO.addComplaint(
                studentId,
                title,
                description,
                category,
                location,
                priority
        );

        if (success) {
            // Trigger Notifications
            try {
                NotificationDAO notifDAO = new NotificationDAO();
                notifDAO.addNotification(
                        studentId,
                        "Ticket Submitted: " + title,
                        "Your report for '" + title + "' at " + location + " has been lodged successfully.",
                        "INFO",
                        "my-complaints"
                );
                notifDAO.notifyAllAdmins(
                        "New " + priority + " Ticket: " + title,
                        "A student reported '" + title + "' in " + location + ". Needs technician allocation.",
                        "WARNING",
                        "admin-complaints"
                );
            } catch (Exception notifEx) {
                notifEx.printStackTrace();
            }

            response.sendRedirect("student-dashboard.jsp?success=true");
        } else {
            response.sendRedirect("complaint.jsp?error=true");
        }
    }
}
