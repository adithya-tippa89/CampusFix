package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.FeedbackDAO;
import com.campusfix.dao.NotificationDAO;
import com.campusfix.dao.UserDAO;
import com.campusfix.model.Complaint;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/submit-feedback")
public class FeedbackServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String email = (String) session.getAttribute("email");
        String complaintIdStr = request.getParameter("complaintId");
        String ratingStr = request.getParameter("rating");
        String comments = request.getParameter("comments");

        try {
            int complaintId = Integer.parseInt(complaintIdStr);
            int rating = Integer.parseInt(ratingStr);

            UserDAO userDAO = new UserDAO();
            int studentId = userDAO.getUserId(email);

            if (studentId != -1) {
                FeedbackDAO feedbackDAO = new FeedbackDAO();
                feedbackDAO.addFeedback(complaintId, studentId, rating, comments);

                // Notify assigned staff about the review
                ComplaintDAO compDAO = new ComplaintDAO();
                Complaint comp = compDAO.getComplaintById(complaintId);
                if (comp != null && comp.getAssignedTo() > 0) {
                    NotificationDAO notifDAO = new NotificationDAO();
                    notifDAO.addNotification(
                            comp.getAssignedTo(),
                            "Student Review: CF-" + complaintId,
                            "The student gave your repair work a " + rating + "-Star Rating! ⭐",
                            "SUCCESS",
                            "staff-complaint?id=" + complaintId
                    );
                }
            }

            response.sendRedirect("my-complaints?feedbackSuccess=true");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("my-complaints?error=true");
        }
    }
}
