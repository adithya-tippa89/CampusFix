package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.UserDAO;
import com.campusfix.model.Complaint;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/my-complaints")
public class MyComplaintsServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Get session

        HttpSession session =
                request.getSession(false);


        // Check login

        if (session == null ||
                session.getAttribute("email") == null) {

            response.sendRedirect("login.jsp");

            return;
        }


        // Get email

        String email =
                (String) session.getAttribute("email");


        // Get student ID

        UserDAO userDAO =
                new UserDAO();

        int studentId =
                userDAO.getUserId(email);


        if (studentId == -1) {

            response.sendRedirect(
                    "student-dashboard.jsp"
            );

            return;
        }


        // Get complaints

        ComplaintDAO complaintDAO =
                new ComplaintDAO();

        List<Complaint> complaints =
                complaintDAO.getComplaintsByStudent(
                        studentId
                );


        // Send complaints to JSP

        request.setAttribute(
                "complaints",
                complaints
        );


        // Open JSP

        request.getRequestDispatcher(
                "my-complaints.jsp"
        ).forward(request, response);
    }
}