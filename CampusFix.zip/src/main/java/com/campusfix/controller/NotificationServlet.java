package com.campusfix.controller;

import com.campusfix.dao.NotificationDAO;
import com.campusfix.dao.UserDAO;
import com.campusfix.model.Notification;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/notifications")
public class NotificationServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String email = (String) session.getAttribute("email");
        UserDAO userDAO = new UserDAO();
        int userId = userDAO.getUserId(email);

        if (userId == -1) {
            response.sendRedirect("login.jsp");
            return;
        }

        NotificationDAO notificationDAO = new NotificationDAO();

        String action = request.getParameter("action");
        if ("readAll".equals(action)) {
            notificationDAO.markAllAsRead(userId);
            response.sendRedirect("notifications");
            return;
        } else if ("read".equals(action)) {
            String notifIdStr = request.getParameter("id");
            if (notifIdStr != null) {
                try {
                    int notifId = Integer.parseInt(notifIdStr);
                    notificationDAO.markAsRead(notifId);
                } catch (NumberFormatException ignored) {}
            }
            String target = request.getParameter("redirect");
            if (target != null && !target.trim().isEmpty()) {
                response.sendRedirect(target);
                return;
            }
            response.sendRedirect("notifications");
            return;
        }

        List<Notification> list = notificationDAO.getNotificationsByUser(userId);
        request.setAttribute("notifications", list);
        request.getRequestDispatcher("notifications.jsp").forward(request, response);
    }
}
