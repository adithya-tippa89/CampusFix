package com.campusfix.controller;

import com.campusfix.dao.UserDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("login.jsp");
    }

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        UserDAO userDAO = new UserDAO();
        boolean validUser = userDAO.validateUser(email, password, role);

        if (validUser) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            session.setAttribute("role", role);

            if ("STUDENT".equals(role)) {
                response.sendRedirect("student-dashboard.jsp");
            } else if ("ADMIN".equals(role)) {
                response.sendRedirect("admin-dashboard.jsp");
            } else if ("STAFF".equals(role)) {
                response.sendRedirect("staff-dashboard.jsp");
            } else {
                response.sendRedirect("student-dashboard.jsp");
            }
        } else {
            response.sendRedirect("login.jsp?error=true");
        }
    }
}
