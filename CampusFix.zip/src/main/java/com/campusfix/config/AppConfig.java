package com.campusfix.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.campusfix")
public class AppConfig {
    // Spring Application Configuration
}
