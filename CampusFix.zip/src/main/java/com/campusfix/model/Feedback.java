package com.campusfix.model;

import java.sql.Timestamp;

/**
 * Model representing student feedback and ratings on resolved campus complaints.
 */
public class Feedback {

    private int id;
    private int complaintId;
    private int studentId;
    private int rating; // 1 to 5 stars
    private String comments;
    private Timestamp createdAt;

    public Feedback() {}

    public Feedback(int complaintId, int studentId, int rating, String comments) {
        this.complaintId = complaintId;
        this.studentId = studentId;
        this.rating = rating;
        this.comments = comments;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(int complaintId) {
        this.complaintId = complaintId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
}
