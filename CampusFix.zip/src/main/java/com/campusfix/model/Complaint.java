package com.campusfix.model;

import java.sql.Timestamp;

public class Complaint {

    private int id;
    private int studentId;

    private String title;
    private String description;
    private String category;
    private String location;
    private String priority;
    private String status;

    // NEW - Staff ID assigned to complaint
    private int assignedTo;

    private Timestamp createdAt;


    // ==============================
    // ID
    // ==============================

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    // ==============================
    // Student ID
    // ==============================

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }


    // ==============================
    // Title
    // ==============================

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    // ==============================
    // Description
    // ==============================

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    // ==============================
    // Category
    // ==============================

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }


    // ==============================
    // Location
    // ==============================

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    // ==============================
    // Priority
    // ==============================

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }


    // ==============================
    // Status
    // ==============================

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    // ==============================
    // Assigned To
    // ==============================

    public int getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(int assignedTo) {
        this.assignedTo = assignedTo;
    }


    // ==============================
    // Created At
    // ==============================

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

}