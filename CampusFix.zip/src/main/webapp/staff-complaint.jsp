<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.campusfix.model.Complaint" %>
<%@ page import="com.campusfix.dao.FeedbackDAO" %>
<%@ page import="com.campusfix.dao.NotificationDAO" %>
<%@ page import="com.campusfix.model.Feedback" %>
<%@ page import="java.text.SimpleDateFormat" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null || !"STAFF".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    Complaint complaint = (Complaint) request.getAttribute("complaint");
    if (complaint == null) {
        response.sendRedirect("staff-complaints");
        return;
    }

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
    String status = complaint.getStatus() != null ? complaint.getStatus().toUpperCase() : "ASSIGNED";
    String priority = complaint.getPriority() != null ? complaint.getPriority().toUpperCase() : "MEDIUM";
    String statusClass = "status-" + status.toLowerCase().replace("_", "-");
    String priorityClass = "priority-" + priority.toLowerCase();

    FeedbackDAO feedbackDAO = new FeedbackDAO();
    Feedback studentFeedback = feedbackDAO.getFeedbackByComplaintId(complaint.getId());

    int unreadNotifs = 0;
    try {
        unreadNotifs = new NotificationDAO().getUnreadCountByEmail(email);
    } catch (Exception ignored) {}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Work Order CF-<%= complaint.getId() %> - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="staff-dashboard.jsp" class="nav-brand">
            <div class="nav-logo-icon" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
                <i class="fa-solid fa-screwdriver-wrench"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge" style="background: rgba(16, 185, 129, 0.25); border-color: #10b981;">Staff</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <!-- Notification Bell -->
            <div class="notif-bell-container">
                <button type="button" class="btn-bell" onclick="toggleNotificationDropdown(event)" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <% if (unreadNotifs > 0) { %>
                        <span class="notif-badge-count"><%= unreadNotifs > 9 ? "9+" : unreadNotifs %></span>
                    <% } %>
                </button>
                <div id="notifDropdown" class="notif-dropdown">
                    <div class="notif-dropdown-header">
                        <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
                        <a href="notifications?action=readAll" style="font-size:12px; color:var(--primary); font-weight:600; text-decoration:none;">Mark all read</a>
                    </div>
                    <div id="notifDropdownList" class="notif-dropdown-body"></div>
                    <div class="notif-dropdown-footer">
                        <a href="notifications">View All Notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <a href="staff-complaints" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-arrow-left"></i> My Work Orders
            </a>
            <div class="user-profile-chip">
                <div class="user-avatar" style="background: linear-gradient(135deg, #10b981 0%, #047857 100%);">S</div>
                <span><%= email %></span>
            </div>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper" style="max-width: 850px;">
        
        <div class="page-header animate-fade-up">
            <div>
                <div style="font-size: 13px; color: var(--text-muted); margin-bottom: 6px;">
                    <a href="staff-dashboard.jsp" style="color: var(--primary); text-decoration: none;">Dashboard</a> &gt; 
                    <a href="staff-complaints" style="color: var(--primary); text-decoration: none;">Assigned Tasks</a> &gt; 
                    <span>CF-<%= complaint.getId() %></span>
                </div>
                <h1 class="page-header-title">
                    <span class="complaint-id-tag" style="font-size: 20px;">CF-<%= complaint.getId() %></span>
                    <%= complaint.getTitle() %>
                </h1>
            </div>
            <div>
                <span class="badge <%= statusClass %>" style="font-size: 14px; padding: 6px 14px;">
                    <span class="badge-dot"></span>
                    <%= status.replace("_", " ") %>
                </span>
            </div>
        </div>

        <!-- Success & Error Alerts -->
        <% if ("true".equals(request.getParameter("success"))) { %>
            <div class="alert alert-success animate-fade-in">
                <i class="fa-solid fa-circle-check"></i>
                <span><strong>Status Updated!</strong> The complaint progress was saved successfully and notified to the student and administration.</span>
            </div>
        <% } %>

        <% if ("true".equals(request.getParameter("error"))) { %>
            <div class="alert alert-error animate-fade-in">
                <i class="fa-solid fa-circle-exclamation"></i>
                <span>Failed to update complaint status. Please select a valid status and try again.</span>
            </div>
        <% } %>

        <!-- Details Card -->
        <div class="detail-card animate-fade-up delay-1">
            
            <div class="detail-header">
                <div>
                    <h2 style="font-size: 18px; color: var(--secondary);">Work Order Details</h2>
                    <p style="font-size: 13px; color: var(--text-muted); margin-top: 2px;">
                        Reported on <%= complaint.getCreatedAt() != null ? dateFormat.format(complaint.getCreatedAt()) : "N/A" %>
                    </p>
                </div>
                <div>
                    <span class="badge <%= priorityClass %>">
                        <% if ("HIGH".equals(priority)) { %>
                            <i class="fa-solid fa-fire"></i>
                        <% } else if ("MEDIUM".equals(priority)) { %>
                            <i class="fa-solid fa-triangle-exclamation"></i>
                        <% } else { %>
                            <i class="fa-solid fa-circle-info"></i>
                        <% } %>
                        <%= priority %> PRIORITY
                    </span>
                </div>
            </div>

            <div class="detail-grid">
                <div class="detail-item">
                    <div class="detail-item-label">
                        <i class="fa-solid fa-layer-group"></i> Category
                    </div>
                    <div class="detail-item-value"><%= complaint.getCategory() %></div>
                </div>

                <div class="detail-item">
                    <div class="detail-item-label">
                        <i class="fa-solid fa-location-dot"></i> Site / Room Location
                    </div>
                    <div class="detail-item-value" style="color: var(--primary);"><%= complaint.getLocation() %></div>
                </div>

                <div class="detail-item">
                    <div class="detail-item-label">
                        <i class="fa-solid fa-user-graduate"></i> Reporter Student ID
                    </div>
                    <div class="detail-item-value">#<%= complaint.getStudentId() %></div>
                </div>

                <div class="detail-item">
                    <div class="detail-item-label">
                        <i class="fa-solid fa-clock"></i> Current Status
                    </div>
                    <div class="detail-item-value">
                        <span class="badge <%= statusClass %>">
                            <span class="badge-dot"></span> <%= status.replace("_", " ") %>
                        </span>
                    </div>
                </div>
            </div>

            <div>
                <div class="detail-item-label" style="margin-bottom: 8px;">
                    <i class="fa-solid fa-align-left"></i> Reported Description
                </div>
                <div class="detail-description-box">
                    <p style="font-size: 14.5px; line-height: 1.7; color: var(--secondary); white-space: pre-wrap;"><%= complaint.getDescription() %></p>
                </div>
            </div>

        </div>

        <!-- Student Feedback Review if present -->
        <% if (studentFeedback != null) { %>
            <div class="detail-card animate-fade-up delay-1" style="border-left: 4px solid #f59e0b;">
                <h2 style="font-size: 18px; color: var(--secondary); margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-star" style="color: #f59e0b;"></i> Student Rating & Feedback
                </h2>
                <div style="font-size: 16px; font-weight: 700; color: #b45309; margin-bottom: 8px;">
                    <% for (int s = 1; s <= 5; s++) { %>
                        <i class="fa-<%= (s <= studentFeedback.getRating()) ? "solid" : "regular" %> fa-star" style="color:#f59e0b;"></i>
                    <% } %>
                    <span style="margin-left: 8px;"><%= studentFeedback.getRating() %> / 5 Stars</span>
                </div>
                <% if (studentFeedback.getComments() != null && !studentFeedback.getComments().trim().isEmpty()) { %>
                    <div class="detail-description-box" style="background: #fffbeb; border-color: #fef08a;">
                        <p style="font-style: italic; color: #78350f;">"<%= studentFeedback.getComments() %>"</p>
                    </div>
                <% } %>
            </div>
        <% } %>

        <!-- Update Status Card -->
        <div class="detail-card animate-fade-up delay-2">
            
            <h2 style="font-size: 18px; color: var(--secondary); margin-bottom: 6px;">
                <i class="fa-solid fa-pen-to-square" style="color: var(--primary);"></i>
                Update Maintenance Status
            </h2>
            <p style="font-size: 13.5px; color: var(--text-muted); margin-bottom: 20px;">
                Keep the student and administration updated on the current state of repairs.
            </p>

            <% if ("RESOLVED".equals(status)) { %>
                
                <div class="alert alert-success" style="margin-bottom: 0;">
                    <i class="fa-solid fa-circle-check" style="font-size: 20px;"></i>
                    <div>
                        <strong>Job Complete!</strong>
                        <p style="font-size: 13px; margin-top: 2px;">This complaint has already been resolved and verified.</p>
                    </div>
                </div>

            <% } else { %>

                <form action="update-status" method="post">
                    
                    <input type="hidden" name="complaintId" value="<%= complaint.getId() %>">

                    <div class="form-group">
                        <label class="form-label" for="status">
                            <i class="fa-solid fa-arrows-rotate"></i> Select Updated Status
                        </label>
                        <select name="status" id="status" class="form-control" required>
                            <option value="" disabled>-- Choose New Status --</option>
                            <option value="IN_PROGRESS" <%= "IN_PROGRESS".equals(status) ? "selected" : "" %>>
                                🔄 In Progress (Currently working on site)
                            </option>
                            <option value="RESOLVED">
                                ✅ Resolved (Fix completed and tested)
                            </option>
                        </select>
                    </div>

                    <div style="display: flex; gap: 12px; margin-top: 16px;">
                        <button type="submit" class="btn btn-primary" style="padding: 12px 24px;">
                            <i class="fa-solid fa-check"></i> Save & Update Status
                        </button>
                        <a href="staff-complaints" class="btn btn-secondary">
                            Back to Tasks
                        </a>
                    </div>

                </form>

            <% } %>

        </div>

    </main>

    <script src="js/main.js"></script>
</body>
</html>
