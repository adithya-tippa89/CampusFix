<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.campusfix.dao.UserDAO" %>
<%@ page import="com.campusfix.dao.NotificationDAO" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null || !"STUDENT".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    UserDAO userDAO = new UserDAO();
    int studentId = userDAO.getUserId(email);
    NotificationDAO notifDAO = new NotificationDAO();
    int unreadNotifs = (studentId != -1) ? notifDAO.getUnreadCount(studentId) : 0;
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Problem - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="student-dashboard.jsp" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-wrench"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge" style="background: rgba(59, 130, 246, 0.25); border-color: #3b82f6;">Student</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <!-- Notification Bell -->
            <div class="notif-bell-container">
                <button type="button" class="btn-bell" onclick="toggleNotificationDropdown(event)" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <% if (unreadNotifs > 0) { %>
                        <span class="notif-badge-count"><%= unreadNotifs > 9 ? "9+" : unreadNotifs %></span>
                    <% } %>
                </button>
                <div id="notifDropdown" class="notif-dropdown">
                    <div class="notif-dropdown-header">
                        <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
                        <a href="notifications?action=readAll" style="font-size:12px; color:var(--primary); font-weight:600; text-decoration:none;">Mark all read</a>
                    </div>
                    <div id="notifDropdownList" class="notif-dropdown-body"></div>
                    <div class="notif-dropdown-footer">
                        <a href="notifications">View All Notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <a href="student-dashboard.jsp" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-arrow-left"></i> Dashboard
            </a>
            <a href="my-complaints" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-list-check"></i> My Complaints
            </a>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper" style="max-width: 760px;">
        
        <div class="page-header animate-fade-up">
            <div>
                <h1 class="page-header-title">
                    <i class="fa-solid fa-bullhorn" style="color: var(--primary);"></i>
                    Report a Campus Problem
                </h1>
                <p class="page-header-desc">
                    Help us keep the campus functional, safe, and clean. Provide clear details to speed up maintenance dispatch.
                </p>
            </div>
        </div>

        <% if (request.getParameter("error") != null) { %>
            <div class="alert alert-error animate-fade-in">
                <i class="fa-solid fa-circle-exclamation"></i>
                <span>Failed to lodge complaint. Please make sure all required fields are filled properly and try again.</span>
            </div>
        <% } %>

        <div class="form-card animate-fade-scale" style="max-width: 100%; padding: 36px 38px;">
            <form action="complaint" method="post" id="complaintForm" enctype="multipart/form-data">
                
                <!-- 1. Problem Title -->
                <div class="form-group">
                    <label class="form-label" for="title">
                        <i class="fa-solid fa-heading"></i> Problem Summary Title <span style="color:#ef4444;">*</span>
                    </label>
                    <div class="input-icon-group">
                        <input type="text"
                               id="title"
                               name="title"
                               class="form-control"
                               placeholder="e.g. Ceiling fan regulator broken in Room 204"
                               required>
                        <i class="fa-solid fa-pen input-icon"></i>
                    </div>
                </div>

                <!-- 2. Visual Category Selector -->
                <div class="form-group">
                    <label class="form-label">
                        <i class="fa-solid fa-layer-group"></i> Issue Category <span style="color:#ef4444;">*</span>
                    </label>
                    
                    <!-- Hidden select input submitted to backend -->
                    <select name="category" id="category" class="form-control" style="display:none;" required>
                        <option value="ELECTRICAL" selected>ELECTRICAL</option>
                        <option value="WIFI">WIFI</option>
                        <option value="LAB">LAB</option>
                        <option value="CLASSROOM">CLASSROOM</option>
                        <option value="HOSTEL">HOSTEL</option>
                        <option value="CLEANING">CLEANING</option>
                        <option value="WATER">WATER</option>
                        <option value="FURNITURE">FURNITURE</option>
                        <option value="OTHER">OTHER</option>
                    </select>

                    <!-- Interactive Visual Tiles Grid -->
                    <div class="category-picker-grid">
                        <div class="cat-picker-item active" data-cat="ELECTRICAL">
                            <span class="cat-icon">⚡</span>
                            <span class="cat-name">Electrical</span>
                        </div>
                        <div class="cat-picker-item" data-cat="WIFI">
                            <span class="cat-icon">📶</span>
                            <span class="cat-name">Wi-Fi / Net</span>
                        </div>
                        <div class="cat-picker-item" data-cat="LAB">
                            <span class="cat-icon">🔬</span>
                            <span class="cat-name">Lab Equip</span>
                        </div>
                        <div class="cat-picker-item" data-cat="CLASSROOM">
                            <span class="cat-icon">🎓</span>
                            <span class="cat-name">Classroom</span>
                        </div>
                        <div class="cat-picker-item" data-cat="HOSTEL">
                            <span class="cat-icon">🛏️</span>
                            <span class="cat-name">Hostel</span>
                        </div>
                        <div class="cat-picker-item" data-cat="WATER">
                            <span class="cat-icon">🚰</span>
                            <span class="cat-name">Plumbing</span>
                        </div>
                        <div class="cat-picker-item" data-cat="CLEANING">
                            <span class="cat-icon">🧹</span>
                            <span class="cat-name">Cleaning</span>
                        </div>
                        <div class="cat-picker-item" data-cat="FURNITURE">
                            <span class="cat-icon">🪑</span>
                            <span class="cat-name">Furniture</span>
                        </div>
                        <div class="cat-picker-item" data-cat="OTHER">
                            <span class="cat-icon">📦</span>
                            <span class="cat-name">Other</span>
                        </div>
                    </div>
                </div>

                <!-- 3. Exact Location with Quick Suggestion Chips -->
                <div class="form-group">
                    <label class="form-label" for="location">
                        <i class="fa-solid fa-location-dot"></i> Campus Location & Room <span style="color:#ef4444;">*</span>
                    </label>
                    <div class="input-icon-group">
                        <input type="text"
                               id="location"
                               name="location"
                               class="form-control"
                               placeholder="e.g. Science Block, 2nd Floor, Room 204"
                               required>
                        <i class="fa-solid fa-location-dot input-icon"></i>
                    </div>

                    <!-- Quick Location Suggestion Chips -->
                    <div style="margin-top: 8px;">
                        <span style="font-size: 11.5px; font-weight: 700; color: var(--text-muted); text-transform: uppercase;">Quick Location Chips:</span>
                        <div class="quick-chips-group">
                            <span class="quick-chip" onclick="applyLocation('Main Admin Block, ')">🏢 Admin Block</span>
                            <span class="quick-chip" onclick="applyLocation('Science Block, ')">🔬 Science Block</span>
                            <span class="quick-chip" onclick="applyLocation('Computer Center Lab, ')">💻 Computer Labs</span>
                            <span class="quick-chip" onclick="applyLocation('Central Library, ')">📚 Central Library</span>
                            <span class="quick-chip" onclick="applyLocation('Boys Hostel Block A, ')">🛏️ Hostel Block A</span>
                            <span class="quick-chip" onclick="applyLocation('Girls Hostel Block B, ')">🛏️ Hostel Block B</span>
                            <span class="quick-chip" onclick="applyLocation('College Cafeteria, ')">☕ Cafeteria</span>
                        </div>
                    </div>
                </div>

                <!-- 4. Priority Selector with Live SLA Commitment Banner -->
                <div class="form-group" style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div>
                        <label class="form-label" for="priority">
                            <i class="fa-solid fa-triangle-exclamation"></i> Issue Priority <span style="color:#ef4444;">*</span>
                        </label>
                        <select name="priority" id="priority" class="form-control" onchange="updateSLAIndicator()" required>
                            <option value="MEDIUM" selected>🟡 Medium (Normal repair)</option>
                            <option value="HIGH">🔴 High (Urgent / Safety Hazard)</option>
                            <option value="LOW">🟢 Low (Minor / Aesthetic)</option>
                        </select>
                    </div>

                    <div>
                        <label class="form-label" for="contactPhone">
                            <i class="fa-solid fa-phone"></i> Contact Phone (Optional)
                        </label>
                        <div class="input-icon-group">
                            <input type="tel"
                                   id="contactPhone"
                                   name="contactPhone"
                                   class="form-control"
                                   placeholder="e.g. 9876543210 (For technician)">
                            <i class="fa-solid fa-phone input-icon"></i>
                        </div>
                    </div>
                </div>

                <!-- Live SLA Indicator Banner -->
                <div id="slaBanner" class="sla-info-banner sla-medium" style="margin-bottom: 22px;">
                    <i id="slaIcon" class="fa-solid fa-clock"></i>
                    <span id="slaText">Standard Priority: Campus technician will attend within <strong>48 Hours (2 Business Days)</strong>.</span>
                </div>

                <!-- 5. Description with Templates & Live Character Counter -->
                <div class="form-group">
                    <div class="textarea-toolbar">
                        <label class="form-label" for="description" style="margin-bottom: 0;">
                            <i class="fa-solid fa-align-left"></i> Detailed Problem Description <span style="color:#ef4444;">*</span>
                        </label>
                        <span id="charCount" class="char-counter">0 / 500 characters</span>
                    </div>

                    <!-- Quick Description Template Inserts -->
                    <div style="display: flex; gap: 8px; margin-bottom: 8px; flex-wrap: wrap;">
                        <span style="font-size: 11.5px; color: var(--text-muted); align-self: center;">Insert Prompt:</span>
                        <button type="button" class="template-btn" onclick="insertTemplate('wifi')">+ Wi-Fi Outage</button>
                        <button type="button" class="template-btn" onclick="insertTemplate('electric')">+ Electrical / Fan</button>
                        <button type="button" class="template-btn" onclick="insertTemplate('water')">+ Water / Plumbing</button>
                        <button type="button" class="template-btn" onclick="insertTemplate('projector')">+ Projector / Display</button>
                    </div>

                    <textarea id="description"
                              name="description"
                              class="form-control"
                              maxlength="500"
                              oninput="updateCharCount()"
                              placeholder="Please describe what is broken, when it started, and any symptoms that can help the technician fix it faster..."
                              required></textarea>
                </div>

                <!-- 6. Photo / Attachment Upload with Live Thumbnail Preview -->
                <div class="form-group">
                    <label class="form-label">
                        <i class="fa-solid fa-camera"></i> Attach Photo / Screenshot (Optional)
                    </label>
                    <div class="photo-upload-box">
                        <input type="file" id="photoInput" name="photoFile" accept="image/*" onchange="handlePhotoUpload(this)">
                        <div style="color: var(--primary); font-size: 26px; margin-bottom: 6px;">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                        </div>
                        <div style="font-weight: 700; font-size: 13.5px; color: var(--secondary);">Click to upload or drag image here</div>
                        <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">Supported: JPG, PNG, WEBP (Max 5MB)</div>
                    </div>

                    <!-- Live Image Preview Card -->
                    <div id="photoPreviewCard" class="photo-preview-card">
                        <img id="previewImg" src="" alt="Photo Preview" class="photo-preview-thumb">
                        <div style="flex: 1;">
                            <div id="photoName" style="font-weight: 700; font-size: 13px; color: var(--secondary);">filename.jpg</div>
                            <div id="photoSize" style="font-size: 11.5px; color: var(--text-muted);">Size: 120 KB</div>
                        </div>
                        <button type="button" onclick="removePhoto()" style="background:none; border:none; color:#ef4444; font-size:16px; cursor:pointer;" title="Remove Photo">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </div>
                </div>

                <!-- Form Action Buttons -->
                <div style="display: flex; gap: 12px; margin-top: 26px;">
                    <button type="button" class="btn btn-secondary" onclick="resetComplaintForm()" style="flex: 1;">
                        <i class="fa-solid fa-rotate-left"></i> Reset
                    </button>
                    <button type="submit" class="btn btn-primary" style="flex: 2;">
                        <i class="fa-solid fa-paper-plane"></i> Submit Complaint
                    </button>
                </div>

            </form>
        </div>

    </main>

    <script src="js/main.js"></script>
    <script>
        // 1. Visual Category Grid Picker Controller
        const catItems = document.querySelectorAll('.cat-picker-item');
        const catSelect = document.getElementById('category');

        catItems.forEach(item => {
            item.addEventListener('click', function() {
                catItems.forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                const selectedCat = this.getAttribute('data-cat');
                catSelect.value = selectedCat;
            });
        });

        // 2. Location Quick Chip Filler
        function applyLocation(locPrefix) {
            const locInput = document.getElementById('location');
            if (locInput.value && !locInput.value.includes(locPrefix)) {
                locInput.value = locPrefix + locInput.value;
            } else {
                locInput.value = locPrefix;
            }
            locInput.focus();
        }

        // 3. Live Priority SLA Indicator
        function updateSLAIndicator() {
            const priority = document.getElementById('priority').value;
            const banner = document.getElementById('slaBanner');
            const icon = document.getElementById('slaIcon');
            const text = document.getElementById('slaText');

            banner.className = 'sla-info-banner';

            if (priority === 'HIGH') {
                banner.classList.add('sla-high');
                icon.className = 'fa-solid fa-triangle-exclamation';
                text.innerHTML = '🚨 Urgent Priority: Emergency technician dispatch targeted within <strong>24 Hours</strong>.';
            } else if (priority === 'MEDIUM') {
                banner.classList.add('sla-medium');
                icon.className = 'fa-solid fa-clock';
                text.innerHTML = '⚙️ Standard Priority: Campus technician will attend within <strong>48 Hours (2 Business Days)</strong>.';
            } else {
                banner.classList.add('sla-low');
                icon.className = 'fa-solid fa-circle-check';
                text.innerHTML = '🌿 Routine Priority: General maintenance scheduled within <strong>72 Hours (3 Business Days)</strong>.';
            }
        }

        // 4. Character Counter
        function updateCharCount() {
            const desc = document.getElementById('description');
            const counter = document.getElementById('charCount');
            counter.textContent = desc.value.length + ' / 500 characters';
        }

        // 5. Description Templates
        function insertTemplate(type) {
            const desc = document.getElementById('description');
            let templateText = '';

            if (type === 'wifi') {
                templateText = "Problem: Wi-Fi signal dropping frequently / Unable to connect to campus network.\nWhen started: Since morning.\nAffected Devices: Multiple laptops and smartphones in the room.";
            } else if (type === 'electric') {
                templateText = "Problem: Ceiling fan / tube light flickering and making buzzing noise.\nWhen started: Today during lecture hours.\nRisk: Sparks observed near the switch board.";
            } else if (type === 'water') {
                templateText = "Problem: Water leakage from washroom tap / water cooler not dispensing.\nLocation details: Washroom next to room.\nUrgency: Water overflowing on floor.";
            } else if (type === 'projector') {
                templateText = "Problem: Classroom projector display blinking / HDMI port not detecting input.\nClass: Room 302\nImpact: Faculty unable to present slides.";
            }

            desc.value = templateText;
            updateCharCount();
            desc.focus();
        }

        // 6. Photo Upload Preview
        function handlePhotoUpload(input) {
            if (input.files && input.files[0]) {
                const file = input.files[0];
                const reader = new FileReader();

                reader.onload = function(e) {
                    document.getElementById('previewImg').src = e.target.result;
                    document.getElementById('photoName').textContent = file.name;
                    document.getElementById('photoSize').textContent = 'Size: ' + Math.round(file.size / 1024) + ' KB';
                    document.getElementById('photoPreviewCard').style.display = 'flex';
                };
                reader.readAsDataURL(file);
            }
        }

        function removePhoto() {
            const input = document.getElementById('photoInput');
            input.value = '';
            document.getElementById('photoPreviewCard').style.display = 'none';
        }

        // 7. Reset Form
        function resetComplaintForm() {
            if (confirm('Are you sure you want to clear all form fields?')) {
                document.getElementById('complaintForm').reset();
                catItems.forEach(i => i.classList.remove('active'));
                catItems[0].classList.add('active');
                catSelect.value = 'ELECTRICAL';
                updateSLAIndicator();
                updateCharCount();
                removePhoto();
            }
        }
    </script>
</body>
</html>
