<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.campusfix.dao.UserDAO" %>
<%@ page import="com.campusfix.dao.ComplaintDAO" %>
<%@ page import="com.campusfix.dao.NotificationDAO" %>
<%@ page import="com.campusfix.model.Complaint" %>
<%@ page import="java.util.List" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null || !"STUDENT".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    // Fetch student summary stats
    UserDAO userDAO = new UserDAO();
    int studentId = userDAO.getUserId(email);

    NotificationDAO notifDAO = new NotificationDAO();
    int unreadNotifs = (studentId != -1) ? notifDAO.getUnreadCount(studentId) : 0;

    ComplaintDAO complaintDAO = new ComplaintDAO();
    List<Complaint> complaints = (studentId != -1) ? complaintDAO.getComplaintsByStudent(studentId) : null;

    int totalCount = (complaints != null) ? complaints.size() : 0;
    int pendingCount = 0;
    int inProgressCount = 0;
    int resolvedCount = 0;

    if (complaints != null) {
        for (Complaint c : complaints) {
            String s = c.getStatus();
            if ("PENDING".equalsIgnoreCase(s)) pendingCount++;
            else if ("IN_PROGRESS".equalsIgnoreCase(s) || "ASSIGNED".equalsIgnoreCase(s)) inProgressCount++;
            else if ("RESOLVED".equalsIgnoreCase(s)) resolvedCount++;
        }
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="student-dashboard.jsp" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-wrench"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge" style="background: rgba(59, 130, 246, 0.25); border-color: #3b82f6;">Student</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <!-- Notification Bell -->
            <div class="notif-bell-container">
                <button type="button" class="btn-bell" onclick="toggleNotificationDropdown(event)" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <% if (unreadNotifs > 0) { %>
                        <span class="notif-badge-count"><%= unreadNotifs > 9 ? "9+" : unreadNotifs %></span>
                    <% } %>
                </button>
                <div id="notifDropdown" class="notif-dropdown">
                    <div class="notif-dropdown-header">
                        <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
                        <a href="notifications?action=readAll" style="font-size:12px; color:var(--primary); font-weight:600; text-decoration:none;">Mark all read</a>
                    </div>
                    <div id="notifDropdownList" class="notif-dropdown-body"></div>
                    <div class="notif-dropdown-footer">
                        <a href="notifications">View All Notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="user-profile-chip">
                <div class="user-avatar"><%= email.length() > 0 ? email.substring(0, 1).toUpperCase() : "S" %></div>
                <span><%= email %></span>
            </div>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper">
        
        <!-- Welcome Section -->
        <div class="page-header animate-fade-up">
            <div>
                <h1 class="page-header-title">
                    <i class="fa-solid fa-house-user" style="color: var(--primary);"></i>
                    Student Dashboard
                </h1>
                <p class="page-header-desc">
                    Welcome back! Report issues across campus and track resolution progress in real time.
                </p>
            </div>
            <div>
                <a href="complaint.jsp" class="btn btn-primary">
                    <i class="fa-solid fa-circle-plus"></i> Report a Problem
                </a>
            </div>
        </div>

        <!-- Success Alert upon reporting -->
        <% if ("true".equals(request.getParameter("success"))) { %>
            <div class="alert alert-success animate-fade-in">
                <i class="fa-solid fa-circle-check"></i>
                <span><strong>Complaint Submitted Successfully!</strong> Your ticket has been logged and forwarded to campus administration.</span>
            </div>
        <% } %>

        <!-- Live Statistics Counter -->
        <section class="stats-banner animate-fade-up delay-1">
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Total Submitted</h4>
                    <div class="stat-number"><%= totalCount %></div>
                </div>
                <div class="stat-icon blue">
                    <i class="fa-solid fa-clipboard-list"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Pending Review</h4>
                    <div class="stat-number"><%= pendingCount %></div>
                </div>
                <div class="stat-icon amber">
                    <i class="fa-solid fa-hourglass-half"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>In Progress / Assigned</h4>
                    <div class="stat-number"><%= inProgressCount %></div>
                </div>
                <div class="stat-icon purple">
                    <i class="fa-solid fa-screwdriver-wrench"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Resolved Issues</h4>
                    <div class="stat-number"><%= resolvedCount %></div>
                </div>
                <div class="stat-icon green">
                    <i class="fa-solid fa-circle-check"></i>
                </div>
            </div>
        </section>

        <!-- Action Cards Grid -->
        <section class="dashboard-grid animate-fade-up delay-2">
            
            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#eff6ff; color:#2563eb;">
                    <i class="fa-solid fa-bullhorn"></i>
                </div>
                <h2>Report a Problem</h2>
                <p>
                    Spotted a broken switch, Wi-Fi outage, lab equipment breakdown, or plumbing issue? Submit a ticket with details and location.
                </p>
                <a href="complaint.jsp" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> New Complaint
                </a>
            </div>

            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#f3e8ff; color:#7e22ce;">
                    <i class="fa-solid fa-list-check"></i>
                </div>
                <h2>My Complaints</h2>
                <p>
                    Review the history of all problems you've submitted, check dates, categories, and assigned technicians.
                </p>
                <a href="my-complaints" class="btn btn-secondary">
                    <i class="fa-solid fa-folder-open"></i> View All Tickets
                </a>
            </div>

            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#dcfce7; color:#16a34a;">
                    <i class="fa-solid fa-timeline"></i>
                </div>
                <h2>Track Status</h2>
                <p>
                    Monitor real-time updates from maintenance staff as your complaints progress from Pending to Assigned and Resolved.
                </p>
                <a href="my-complaints" class="btn btn-secondary">
                    <i class="fa-solid fa-arrows-rotate"></i> Track Status
                </a>
            </div>

        </section>

    </main>

    <script src="js/main.js"></script>
</body>
</html>
