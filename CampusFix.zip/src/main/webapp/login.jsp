<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="index.jsp" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-wrench"></i>
            </div>
            <div class="nav-title">CampusFix</div>
        </a>
        <div class="nav-actions">
            <a href="index.jsp" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-house"></i> Home
            </a>
            <a href="register.jsp" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-user-plus"></i> Register
            </a>
        </div>
    </header>

    <!-- Auth Container -->
    <div class="auth-wrapper">
        <div class="auth-card animate-fade-scale">
            
            <div class="auth-header">
                <div class="auth-logo-badge">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <h1>Welcome Back</h1>
                <p>Sign in to your CampusFix account</p>
            </div>

            <!-- Alerts -->
            <% if ("true".equals(request.getParameter("registered"))) { %>
                <div class="alert alert-success">
                    <i class="fa-solid fa-circle-check"></i>
                    <span>Registration successful! Please login with your credentials.</span>
                </div>
            <% } %>

            <% if ("true".equals(request.getParameter("logout"))) { %>
                <div class="alert alert-info">
                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                    <span>You have been securely logged out.</span>
                </div>
            <% } %>

            <% if (request.getParameter("error") != null) { %>
                <div class="alert alert-error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span>Invalid email, password, or role. Please try again.</span>
                </div>
            <% } %>

            <form action="login" method="post">
                
                <div class="form-group">
                    <label class="form-label" for="email">
                        <i class="fa-regular fa-envelope"></i> College Email Address
                    </label>
                    <div class="input-icon-group">
                        <input type="email" 
                               id="email"
                               name="email" 
                               class="form-control" 
                               placeholder="e.g. rollno@college.edu" 
                               required 
                               autocomplete="email">
                        <i class="fa-regular fa-envelope input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">
                        <i class="fa-solid fa-lock"></i> Password
                    </label>
                    <div class="input-icon-group">
                        <input type="password" 
                               id="password"
                               name="password" 
                               class="form-control" 
                               placeholder="Enter your password" 
                               required 
                               autocomplete="current-password">
                        <i class="fa-solid fa-lock input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="role">
                        <i class="fa-solid fa-user-tag"></i> Portal Role
                    </label>
                    <div class="input-icon-group">
                        <select name="role" id="role" class="form-control" required>
                            <option value="" disabled selected>-- Select Your Role --</option>
                            <option value="STUDENT">🎓 Student</option>
                            <option value="STAFF">🛠️ Maintenance Staff</option>
                            <option value="ADMIN">🛡️ Administrator</option>
                        </select>
                        <i class="fa-solid fa-user-gear input-icon"></i>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 10px; padding: 13px;">
                    <i class="fa-solid fa-right-to-bracket"></i> Sign In to Account
                </button>

            </form>

            <div class="auth-footer">
                Don't have an account yet? 
                <a href="register.jsp">Create Account</a>
            </div>

        </div>
    </div>

    <script src="js/main.js"></script>
</body>
</html>
