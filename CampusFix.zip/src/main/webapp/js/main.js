/**
 * CampusFix - Interactive Micro-Animations & UX Enhancements
 */

document.addEventListener('DOMContentLoaded', function () {
    // 1. Password Visibility Toggle
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(input => {
        const wrapper = input.parentElement;
        if (wrapper && wrapper.classList.contains('input-icon-group')) {
            const toggleBtn = document.createElement('span');
            toggleBtn.className = 'password-toggle-icon';
            toggleBtn.innerHTML = '<i class="fa-regular fa-eye"></i>';
            toggleBtn.style.cssText = 'position: absolute; right: 14px; top: 50%; transform: translateY(-50%); cursor: pointer; color: #94a3b8; font-size: 15px; transition: color 0.2s;';
            
            toggleBtn.addEventListener('click', function () {
                if (input.type === 'password') {
                    input.type = 'text';
                    toggleBtn.innerHTML = '<i class="fa-regular fa-eye-slash"></i>';
                    toggleBtn.style.color = '#2563eb';
                } else {
                    input.type = 'password';
                    toggleBtn.innerHTML = '<i class="fa-regular fa-eye"></i>';
                    toggleBtn.style.color = '#94a3b8';
                }
            });
            wrapper.style.position = 'relative';
            wrapper.appendChild(toggleBtn);
        }
    });

    // 2. Real-time Table Search Filter
    const searchInput = document.getElementById('tableSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const query = this.value.toLowerCase().trim();
            const table = document.querySelector('.data-table tbody');
            if (!table) return;

            const rows = table.querySelectorAll('tr');
            let visibleCount = 0;

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(query)) {
                    row.style.display = '';
                    visibleCount++;
                } else {
                    row.style.display = 'none';
                }
            });

            // If empty search result
            let noMatchEl = document.getElementById('noSearchResult');
            if (visibleCount === 0) {
                if (!noMatchEl) {
                    noMatchEl = document.createElement('div');
                    noMatchEl.id = 'noSearchResult';
                    noMatchEl.className = 'empty-state';
                    noMatchEl.innerHTML = '<div class="empty-icon"><i class="fa-solid fa-magnifying-glass"></i></div><h3>No matching records</h3><p>Try searching with another keyword.</p>';
                    table.parentElement.parentElement.appendChild(noMatchEl);
                }
                noMatchEl.style.display = 'block';
            } else if (noMatchEl) {
                noMatchEl.style.display = 'none';
            }
        });
    }

    // 3. Status Filter Buttons (if present)
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            const targetStatus = this.getAttribute('data-status').toLowerCase();

            const rows = document.querySelectorAll('.data-table tbody tr');
            rows.forEach(row => {
                if (targetStatus === 'all') {
                    row.style.display = '';
                } else {
                    const statusText = row.querySelector('.badge')?.textContent.toLowerCase() || '';
                    if (statusText.includes(targetStatus)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                }
            });
        });
    });

    // 4. Form Submit Button Micro-Animation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function () {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn && !submitBtn.disabled) {
                const originalText = submitBtn.innerHTML;
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Processing...';
                // Fallback reset after 8 seconds in case response is fast
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                }, 8000);
            }
        });
    });

    // 5. Alert Auto Dismiss / Close button
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        const closeBtn = document.createElement('button');
        closeBtn.innerHTML = '&times;';
        closeBtn.style.cssText = 'margin-left: auto; background: none; border: none; font-size: 20px; line-height: 1; cursor: pointer; opacity: 0.6; padding: 0 4px;';
        closeBtn.addEventListener('click', () => {
            alert.style.transition = 'opacity 0.3s, transform 0.3s';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(() => alert.remove(), 300);
        });
        alert.appendChild(closeBtn);
    });
});


// 6. Future Implementation: CSV Export Feature
function exportTableToCSV(filename = 'campusfix_export.csv') {
    const table = document.querySelector('.data-table');
    if (!table) return;

    let csv = [];
    const rows = table.querySelectorAll('tr');

    for (let i = 0; i < rows.length; i++) {
        // Skip hidden rows if filtered
        if (rows[i].style.display === 'none') continue;

        let row = [], cols = rows[i].querySelectorAll('td, th');
        for (let j = 0; j < cols.length; j++) {
            // Remove actions column or cleanup text
            let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, ' ').replace(/\s+/g, ' ').trim();
            data = data.replace(/"/g, '""');
            row.push('"' + data + '"');
        }
        csv.push(row.join(','));
    }

    const csvFile = new Blob([csv.join('\n')], { type: 'text/csv' });
    const downloadLink = document.createElement('a');
    downloadLink.download = filename;
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = 'none';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}

// 7. Future Implementation: Rating Modal Controller
function openRatingModal(complaintId, title) {
    const modal = document.getElementById('ratingModal');
    if (!modal) return;
    document.getElementById('modalComplaintId').value = complaintId;
    document.getElementById('modalComplaintTitle').textContent = 'CF-' + complaintId + ': ' + title;
    modal.style.display = 'flex';
}

function closeRatingModal() {
    const modal = document.getElementById('ratingModal');
    if (modal) modal.style.display = 'none';
}


// 8. Notification Bell Dropdown & Real-time Fetch
function toggleNotificationDropdown(event) {
    if (event) event.stopPropagation();
    const dropdown = document.getElementById('notifDropdown');
    if (!dropdown) return;

    if (dropdown.style.display === 'block') {
        dropdown.style.display = 'none';
    } else {
        dropdown.style.display = 'block';
        loadNotificationsIntoDropdown();
    }
}

function loadNotificationsIntoDropdown() {
    const listContainer = document.getElementById('notifDropdownList');
    if (!listContainer) return;

    fetch('api/notifications?limit=5')
        .then(res => res.json())
        .then(data => {
            if (!data || data.length === 0) {
                listContainer.innerHTML = '<div style="padding: 24px; text-align: center; color: #94a3b8; font-size: 13px;"><i class="fa-regular fa-bell-slash" style="font-size:20px; margin-bottom:6px; display:block;"></i>No new notifications</div>';
                return;
            }

            let html = '';
            data.forEach(n => {
                let icon = 'fa-solid fa-circle-info';
                let iconColor = 'var(--primary)';
                if (n.type === 'SUCCESS') { icon = 'fa-solid fa-circle-check'; iconColor = '#16a34a'; }
                else if (n.type === 'WARNING') { icon = 'fa-solid fa-triangle-exclamation'; iconColor = '#d97706'; }
                else if (n.type === 'ASSIGNMENT') { icon = 'fa-solid fa-screwdriver-wrench'; iconColor = '#7e22ce'; }

                const bgClass = n.read ? 'notif-read' : 'notif-unread';
                const linkUrl = n.link ? n.link : '#';
                const clickUrl = 'notifications?action=read&id=' + n.id + '&redirect=' + encodeURIComponent(linkUrl);

                html += `
                    <a href="${clickUrl}" class="notification-item ${bgClass}">
                        <div class="notif-icon-circle" style="color: ${iconColor};">
                            <i class="${icon}"></i>
                        </div>
                        <div style="flex: 1;">
                            <div style="display:flex; justify-content:space-between; align-items:baseline;">
                                <div class="notif-title">${n.title}</div>
                                ${!n.read ? '<span class="badge-dot" style="background:#2563eb;"></span>' : ''}
                            </div>
                            <div class="notif-message">${n.message}</div>
                        </div>
                    </a>
                `;
            });
            listContainer.innerHTML = html;
        })
        .catch(() => {
            // Fallback gracefully
        });
}

// Close dropdown on outside click
document.addEventListener('click', function(e) {
    const container = document.querySelector('.notif-bell-container');
    const dropdown = document.getElementById('notifDropdown');
    if (dropdown && container && !container.contains(e.target)) {
        dropdown.style.display = 'none';
    }
});
