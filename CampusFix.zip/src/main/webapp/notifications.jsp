<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.campusfix.model.Notification" %>
<%@ page import="com.campusfix.dao.UserDAO" %>
<%@ page import="java.text.SimpleDateFormat" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null) {
        response.sendRedirect("login.jsp");
        return;
    }

    List<Notification> notifications = (List<Notification>) request.getAttribute("notifications");
    if (notifications == null) {
        response.sendRedirect("notifications");
        return;
    }

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM, hh:mm a");

    String dashLink = "student-dashboard.jsp";
    if ("ADMIN".equals(role)) dashLink = "admin-dashboard.jsp";
    else if ("STAFF".equals(role)) dashLink = "staff-dashboard.jsp";
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Notifications - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="<%= dashLink %>" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-wrench"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge"><%= role %></span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <a href="<%= dashLink %>" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-house"></i> Dashboard
            </a>
            <div class="user-profile-chip">
                <div class="user-avatar"><%= email.length() > 0 ? email.substring(0, 1).toUpperCase() : "U" %></div>
                <span><%= email %></span>
            </div>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper" style="max-width: 860px;">
        
        <div class="page-header animate-fade-up">
            <div>
                <h1 class="page-header-title">
                    <i class="fa-solid fa-bell" style="color: var(--primary);"></i>
                    Notification Center
                </h1>
                <p class="page-header-desc">
                    Stay informed on ticket status transitions, assignments, and campus repair progress.
                </p>
            </div>
            <div style="display: flex; gap: 10px;">
                <a href="notifications?action=readAll" class="btn btn-secondary btn-sm">
                    <i class="fa-solid fa-check-double"></i> Mark All as Read
                </a>
                <a href="<%= dashLink %>" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-arrow-left"></i> Dashboard
                </a>
            </div>
        </div>

        <% if (notifications.isEmpty()) { %>
            <div class="table-card empty-state animate-fade-scale">
                <div class="empty-icon">
                    <i class="fa-regular fa-bell-slash"></i>
                </div>
                <h3>No Notifications Yet</h3>
                <p>You're all caught up! When there are updates on campus complaints or repair work, you'll see them right here.</p>
                <a href="<%= dashLink %>" class="btn btn-secondary">
                    Back to Dashboard
                </a>
            </div>
        <% } else { %>

            <div class="table-card animate-fade-up delay-1" style="padding: 10px 0;">
                <div class="notification-list">
                    <% for (Notification n : notifications) { 
                        String icon = "fa-solid fa-circle-info";
                        String iconColor = "var(--primary)";
                        String bgClass = n.isRead() ? "notif-read" : "notif-unread";

                        if ("SUCCESS".equalsIgnoreCase(n.getType())) {
                            icon = "fa-solid fa-circle-check";
                            iconColor = "#16a34a";
                        } else if ("WARNING".equalsIgnoreCase(n.getType())) {
                            icon = "fa-solid fa-triangle-exclamation";
                            iconColor = "#d97706";
                        } else if ("ASSIGNMENT".equalsIgnoreCase(n.getType())) {
                            icon = "fa-solid fa-screwdriver-wrench";
                            iconColor = "#7e22ce";
                        }

                        String linkUrl = (n.getLink() != null && !n.getLink().isEmpty()) ? n.getLink() : "#";
                        String clickUrl = "notifications?action=read&id=" + n.getId() + "&redirect=" + linkUrl;
                    %>
                    <a href="<%= clickUrl %>" class="notification-item <%= bgClass %>">
                        <div class="notif-icon-circle" style="color: <%= iconColor %>;">
                            <i class="<%= icon %>"></i>
                        </div>
                        <div style="flex: 1;">
                            <div style="display: flex; justify-content: space-between; align-items: baseline; gap: 10px;">
                                <h4 class="notif-title">
                                    <%= n.getTitle() %>
                                    <% if (!n.isRead()) { %>
                                        <span class="badge-dot" style="display: inline-block; background-color: var(--primary); margin-left: 6px;" title="Unread"></span>
                                    <% } %>
                                </h4>
                                <span class="notif-time">
                                    <i class="fa-regular fa-clock"></i> <%= n.getCreatedAt() != null ? dateFormat.format(n.getCreatedAt()) : "" %>
                                </span>
                            </div>
                            <p class="notif-message"><%= n.getMessage() %></p>
                        </div>
                    </a>
                    <% } %>
                </div>
            </div>

        <% } %>

    </main>

    <script src="js/main.js"></script>
</body>
</html>
