<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.campusfix.model.Complaint" %>
<%@ page import="com.campusfix.dao.FeedbackDAO" %>
<%@ page import="com.campusfix.dao.NotificationDAO" %>
<%@ page import="com.campusfix.model.Feedback" %>
<%@ page import="java.text.SimpleDateFormat" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null || !"STUDENT".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    List<Complaint> complaints = (List<Complaint>) request.getAttribute("complaints");
    if (complaints == null) {
        response.sendRedirect("my-complaints");
        return;
    }

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
    FeedbackDAO feedbackDAO = new FeedbackDAO();
    int unreadNotifs = 0;
    try {
        unreadNotifs = new NotificationDAO().getUnreadCountByEmail(email);
    } catch (Exception ignored) {}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Complaints - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="student-dashboard.jsp" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-wrench"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge" style="background: rgba(59, 130, 246, 0.25); border-color: #3b82f6;">Student</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <!-- Notification Bell -->
            <div class="notif-bell-container">
                <button type="button" class="btn-bell" onclick="toggleNotificationDropdown(event)" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <% if (unreadNotifs > 0) { %>
                        <span class="notif-badge-count"><%= unreadNotifs > 9 ? "9+" : unreadNotifs %></span>
                    <% } %>
                </button>
                <div id="notifDropdown" class="notif-dropdown">
                    <div class="notif-dropdown-header">
                        <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
                        <a href="notifications?action=readAll" style="font-size:12px; color:var(--primary); font-weight:600; text-decoration:none;">Mark all read</a>
                    </div>
                    <div id="notifDropdownList" class="notif-dropdown-body"></div>
                    <div class="notif-dropdown-footer">
                        <a href="notifications">View All Notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <a href="student-dashboard.jsp" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-house"></i> Dashboard
            </a>
            <a href="complaint.jsp" class="btn btn-primary btn-sm">
                <i class="fa-solid fa-plus"></i> New Complaint
            </a>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper">
        
        <div class="page-header animate-fade-up">
            <div>
                <h1 class="page-header-title">
                    <i class="fa-solid fa-list-check" style="color: var(--primary);"></i>
                    My Reported Complaints
                </h1>
                <p class="page-header-desc">
                    View real-time updates and maintenance tracking on all issues you have submitted.
                </p>
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="button" class="btn btn-secondary" onclick="exportTableToCSV('my_campus_complaints.csv')">
                    <i class="fa-solid fa-file-csv"></i> Export CSV
                </button>
                <a href="complaint.jsp" class="btn btn-primary">
                    <i class="fa-solid fa-bullhorn"></i> Lodge New Complaint
                </a>
            </div>
        </div>

        <% if ("true".equals(request.getParameter("feedbackSuccess"))) { %>
            <div class="alert alert-success animate-fade-in">
                <i class="fa-solid fa-star" style="color: #f59e0b;"></i>
                <span><strong>Thank You!</strong> Your rating & feedback has been submitted successfully to help improve our campus maintenance!</span>
            </div>
        <% } %>

        <% if (complaints.isEmpty()) { %>
            
            <div class="table-card empty-state animate-fade-scale">
                <div class="empty-icon">
                    <i class="fa-solid fa-clipboard-check"></i>
                </div>
                <h3>No Complaints Lodged Yet</h3>
                <p>Everything seems to be running fine! If you notice any problem on campus, click below to let maintenance know.</p>
                <a href="complaint.jsp" class="btn btn-primary">
                    <i class="fa-solid fa-plus"></i> Report a Problem
                </a>
            </div>

        <% } else { %>

            <div class="table-card animate-fade-up delay-1">
                
                <!-- Table Toolbar (Search & Filter) -->
                <div class="table-toolbar">
                    <div class="input-icon-group" style="margin-bottom: 0;">
                        <input type="text" 
                               id="tableSearch" 
                               class="table-search-input" 
                               placeholder="Search title, category, ID...">
                        <i class="fa-solid fa-magnifying-glass input-icon"></i>
                    </div>

                    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                        <button type="button" class="btn btn-sm btn-secondary filter-btn active" data-status="all">All (<%= complaints.size() %>)</button>
                        <button type="button" class="btn btn-sm btn-secondary filter-btn" data-status="pending">Pending</button>
                        <button type="button" class="btn btn-sm btn-secondary filter-btn" data-status="assigned">Assigned</button>
                        <button type="button" class="btn btn-sm btn-secondary filter-btn" data-status="in_progress">In Progress</button>
                        <button type="button" class="btn btn-sm btn-secondary filter-btn" data-status="resolved">Resolved</button>
                    </div>
                </div>

                <!-- Data Table -->
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Ticket ID</th>
                                <th>Problem Title</th>
                                <th>Category</th>
                                <th>Location</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Lodged Date</th>
                                <th style="text-align: right;">Feedback & Review</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for (Complaint complaint : complaints) { 
                                String status = complaint.getStatus() != null ? complaint.getStatus().toUpperCase() : "PENDING";
                                String priority = complaint.getPriority() != null ? complaint.getPriority().toUpperCase() : "MEDIUM";
                                String statusClass = "status-" + status.toLowerCase().replace("_", "-");
                                String priorityClass = "priority-" + priority.toLowerCase();
                                Feedback fb = "RESOLVED".equals(status) ? feedbackDAO.getFeedbackByComplaintId(complaint.getId()) : null;
                            %>
                            <tr>
                                <td>
                                    <span class="complaint-id-tag">CF-<%= complaint.getId() %></span>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--secondary);"><%= complaint.getTitle() %></div>
                                    <% if (complaint.getDescription() != null && !complaint.getDescription().isEmpty()) { 
                                        String descSnippet = complaint.getDescription();
                                        if (descSnippet.length() > 60) {
                                            descSnippet = descSnippet.substring(0, 60) + "...";
                                        }
                                    %>
                                        <div style="font-size: 12.5px; color: var(--text-muted); margin-top: 2px;"><%= descSnippet %></div>
                                    <% } %>
                                </td>
                                <td>
                                    <span class="category-pill">
                                        <i class="fa-solid fa-tag"></i> <%= complaint.getCategory() %>
                                    </span>
                                </td>
                                <td>
                                    <span style="font-weight: 500; font-size: 13.5px;">
                                        <i class="fa-solid fa-location-dot" style="color: var(--text-muted); margin-right: 4px;"></i>
                                        <%= complaint.getLocation() %>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <%= priorityClass %>">
                                        <% if ("HIGH".equals(priority)) { %>
                                            <i class="fa-solid fa-fire"></i>
                                        <% } else if ("MEDIUM".equals(priority)) { %>
                                            <i class="fa-solid fa-triangle-exclamation"></i>
                                        <% } else { %>
                                            <i class="fa-solid fa-circle-info"></i>
                                        <% } %>
                                        <%= priority %>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <%= statusClass %>">
                                        <span class="badge-dot"></span>
                                        <%= status.replace("_", " ") %>
                                    </span>
                                </td>
                                <td style="color: var(--text-muted); font-size: 13px; white-space: nowrap;">
                                    <% if (complaint.getCreatedAt() != null) { %>
                                        <i class="fa-regular fa-clock"></i> <%= dateFormat.format(complaint.getCreatedAt()) %>
                                    <% } else { %>
                                        --
                                    <% } %>
                                </td>
                                <td style="text-align: right;">
                                    <% if ("RESOLVED".equals(status)) { %>
                                        <% if (fb != null) { %>
                                            <span style="color: #eab308; font-weight: 700; font-size: 13px; display: inline-flex; align-items: center; gap: 4px;">
                                                <i class="fa-solid fa-star"></i> <%= fb.getRating() %>/5 Rated
                                            </span>
                                        <% } else { %>
                                            <button type="button" 
                                                    onclick="openRatingModal(<%= complaint.getId() %>, '<%= complaint.getTitle().replace("'", "\\'") %>')"
                                                    class="btn btn-sm" 
                                                    style="background: #fef08a; color: #854d0e; border: 1px solid #fde047; font-weight: 700;">
                                                <i class="fa-solid fa-star"></i> Rate Repair
                                            </button>
                                        <% } %>
                                    <% } else { %>
                                        <span style="color: var(--text-light); font-size: 12.5px;">In Progress</span>
                                    <% } %>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>

            </div>

        <% } %>

    </main>

    <!-- Future Implementation: Star Rating & Review Modal -->
    <div id="ratingModal" class="modal-backdrop">
        <div class="modal-dialog">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
                <h3 style="font-size: 18px; color: var(--secondary);">
                    <i class="fa-solid fa-star" style="color: #f59e0b;"></i> Rate Maintenance Repair
                </h3>
                <button type="button" onclick="closeRatingModal()" style="background:none; border:none; font-size:22px; cursor:pointer; color:#94a3b8;">&times;</button>
            </div>
            
            <p id="modalComplaintTitle" style="font-weight: 600; color: var(--primary); font-size: 14px; margin-bottom: 12px;"></p>
            <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 16px;">How satisfied are you with the resolution of this issue?</p>

            <form action="submit-feedback" method="post">
                <input type="hidden" id="modalComplaintId" name="complaintId" value="">

                <div class="star-rating-group">
                    <input type="radio" id="star5" name="rating" value="5" required checked><label for="star5" title="5 stars"><i class="fa-solid fa-star"></i></label>
                    <input type="radio" id="star4" name="rating" value="4"><label for="star4" title="4 stars"><i class="fa-solid fa-star"></i></label>
                    <input type="radio" id="star3" name="rating" value="3"><label for="star3" title="3 stars"><i class="fa-solid fa-star"></i></label>
                    <input type="radio" id="star2" name="rating" value="2"><label for="star2" title="2 stars"><i class="fa-solid fa-star"></i></label>
                    <input type="radio" id="star1" name="rating" value="1"><label for="star1" title="1 star"><i class="fa-solid fa-star"></i></label>
                </div>

                <div class="form-group">
                    <label class="form-label" for="comments">Your Feedback / Review (Optional)</label>
                    <textarea name="comments" id="comments" class="form-control" placeholder="e.g. Technician arrived on time and fixed the switch quickly." style="height: 80px;"></textarea>
                </div>

                <div style="display: flex; gap: 10px; margin-top: 18px;">
                    <button type="button" class="btn btn-secondary" onclick="closeRatingModal()" style="flex: 1;">Cancel</button>
                    <button type="submit" class="btn btn-primary" style="flex: 2;">
                        <i class="fa-solid fa-check"></i> Submit Rating
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="js/main.js"></script>
</body>
</html>
