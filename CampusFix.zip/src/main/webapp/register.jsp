<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="index.jsp" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-wrench"></i>
            </div>
            <div class="nav-title">CampusFix</div>
        </a>
        <div class="nav-actions">
            <a href="index.jsp" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-house"></i> Home
            </a>
            <a href="login.jsp" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-right-to-bracket"></i> Login
            </a>
        </div>
    </header>

    <!-- Auth Container -->
    <div class="auth-wrapper">
        <div class="auth-card animate-fade-scale" style="max-width: 480px;">
            
            <div class="auth-header">
                <div class="auth-logo-badge" style="background: linear-gradient(135deg, #4338ca 0%, #6366f1 100%);">
                    <i class="fa-solid fa-user-plus"></i>
                </div>
                <h1>Create Account</h1>
                <p>Register as a Student or Campus Staff</p>
            </div>

            <!-- Error Alerts -->
            <% if ("exists".equals(request.getParameter("error"))) { %>
                <div class="alert alert-error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span>This email is already registered. Please sign in or use another email.</span>
                </div>
            <% } %>

            <% if ("failed".equals(request.getParameter("error"))) { %>
                <div class="alert alert-error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span>Passwords do not match or registration failed. Please try again.</span>
                </div>
            <% } %>

            <form action="register" method="post" id="registerForm">
                
                <div class="form-group">
                    <label class="form-label" for="name">
                        <i class="fa-regular fa-user"></i> Full Name
                    </label>
                    <div class="input-icon-group">
                        <input type="text" 
                               id="name"
                               name="name" 
                               class="form-control" 
                               placeholder="e.g. Rahul Sharma" 
                               required 
                               autocomplete="name">
                        <i class="fa-regular fa-user input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="email">
                        <i class="fa-regular fa-envelope"></i> Email Address
                    </label>
                    <div class="input-icon-group">
                        <input type="email" 
                               id="email"
                               name="email" 
                               class="form-control" 
                               placeholder="e.g. rahul@college.edu" 
                               required 
                               autocomplete="email">
                        <i class="fa-regular fa-envelope input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">
                        <i class="fa-solid fa-lock"></i> Password
                    </label>
                    <div class="input-icon-group">
                        <input type="password" 
                               id="password"
                               name="password" 
                               class="form-control" 
                               placeholder="Create a secure password" 
                               required>
                        <i class="fa-solid fa-lock input-icon"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="confirmPassword">
                        <i class="fa-solid fa-shield-check"></i> Confirm Password
                    </label>
                    <div class="input-icon-group">
                        <input type="password" 
                               id="confirmPassword"
                               name="confirmPassword" 
                               class="form-control" 
                               placeholder="Repeat your password" 
                               required>
                        <i class="fa-solid fa-shield-check input-icon"></i>
                    </div>
                    <small id="pwMatchNote" style="display:none; font-size:12px; margin-top:4px; font-weight:600;"></small>
                </div>

                <div class="form-group">
                    <label class="form-label" for="role">
                        <i class="fa-solid fa-id-badge"></i> Account Type
                    </label>
                    <div class="input-icon-group">
                        <select name="role" id="role" class="form-control" required>
                            <option value="" disabled selected>-- Choose Account Role --</option>
                            <option value="STUDENT">🎓 Student</option>
                            <option value="STAFF">🛠️ Maintenance Staff</option>
                        </select>
                        <i class="fa-solid fa-user-tag input-icon"></i>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block" style="margin-top: 10px; padding: 13px;">
                    <i class="fa-solid fa-user-check"></i> Complete Registration
                </button>

            </form>

            <div class="auth-footer">
                Already registered? 
                <a href="login.jsp">Sign In Here</a>
            </div>

        </div>
    </div>

    <script src="js/main.js"></script>
    <script>
        // Live client-side password matching helper
        const pw = document.getElementById('password');
        const cpw = document.getElementById('confirmPassword');
        const note = document.getElementById('pwMatchNote');

        function checkMatch() {
            if (!cpw.value) {
                note.style.display = 'none';
                return;
            }
            note.style.display = 'block';
            if (pw.value === cpw.value) {
                note.textContent = '✓ Passwords match';
                note.style.color = '#16a34a';
            } else {
                note.textContent = '✗ Passwords do not match';
                note.style.color = '#dc2626';
            }
        }
        if (pw && cpw) {
            pw.addEventListener('input', checkMatch);
            cpw.addEventListener('input', checkMatch);
        }
    </script>
</body>
</html>
