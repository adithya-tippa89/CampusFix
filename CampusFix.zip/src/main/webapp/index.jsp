<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusFix - Smart College Problem Management System</title>
    <!-- Google Fonts & Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Top Navigation -->
    <header class="navbar">
        <a href="index.jsp" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-wrench"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge">Official Portal</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <a href="login.jsp" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-arrow-right-to-bracket"></i> Login
            </a>
            <a href="register.jsp" class="btn btn-primary btn-sm">
                <i class="fa-solid fa-user-plus"></i> Register
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper">
        
        <!-- Modern 2-Column Hero Section with Image -->
        <section class="hero-split-grid animate-fade-up">
            
            <!-- Left Column: Copy & Actions -->
            <div class="hero-content-col">
                <div class="hero-pill">
                    <i class="fa-solid fa-bolt"></i> Fast & Transparent Campus Maintenance
                </div>
                <h1 class="hero-title">
                    Smart Problem Management for <span>Our Campus</span>
                </h1>
                <p class="hero-desc">
                    Encountering an issue in your classroom, lab, hostel, or campus grounds? Report it instantly, track progress in real-time, and get it resolved by dedicated campus maintenance staff.
                </p>
                
                <div class="hero-cta">
                    <a href="login.jsp" class="btn btn-primary" style="padding: 13px 26px; font-size: 15px;">
                        <i class="fa-solid fa-right-to-bracket"></i> Login to Portal
                    </a>
                    <a href="register.jsp" class="btn btn-secondary" style="padding: 13px 26px; font-size: 15px;">
                        <i class="fa-solid fa-user-plus"></i> Create Account
                    </a>
                </div>

                <div class="hero-feature-pills">
                    <span><i class="fa-solid fa-circle-check"></i> Paperless Ticketing</span>
                    <span><i class="fa-solid fa-circle-check"></i> Real-time Staff Routing</span>
                    <span><i class="fa-solid fa-circle-check"></i> 100% Transparent</span>
                </div>
            </div>

            <!-- Right Column: Hero Visual Graphic with Floating Status Cards -->
            <div class="hero-image-wrapper">
                
                <!-- Floating Badge 1 (Top Right) -->
                <div class="floating-badge-card floating-card-1">
                    <div style="width:36px; height:36px; border-radius:50%; background:#dbeafe; color:#2563eb; display:flex; align-items:center; justify-content:center; font-size:16px;">
                        <i class="fa-solid fa-wifi"></i>
                    </div>
                    <div>
                        <div style="font-size:12px; font-weight:800; color:var(--secondary);">Lab Wi-Fi Outage</div>
                        <span class="badge status-resolved" style="padding:2px 8px; font-size:11px; margin-top:2px;">
                            <span class="badge-dot"></span> Resolved
                        </span>
                    </div>
                </div>

                <!-- Main Hero Illustration / Image -->
                <img src="images/campus-hero.png" 
                     alt="CampusFix Smart Facility Maintenance System" 
                     class="hero-main-img"
                     onerror="this.onerror=null; this.src='images/campus-illustration.svg';">

                <!-- Floating Badge 2 (Bottom Left) -->
                <div class="floating-badge-card floating-card-2">
                    <div style="width:36px; height:36px; border-radius:50%; background:#fef3c7; color:#d97706; display:flex; align-items:center; justify-content:center; font-size:16px;">
                        <i class="fa-solid fa-bolt"></i>
                    </div>
                    <div>
                        <div style="font-size:12px; font-weight:800; color:var(--secondary);">Room 302 Projector</div>
                        <span class="badge status-in-progress" style="padding:2px 8px; font-size:11px; margin-top:2px;">
                            <span class="badge-dot"></span> In Progress
                        </span>
                    </div>
                </div>

            </div>

        </section>

        <!-- Stats Counter / Highlight Banner -->
        <section class="stats-banner animate-fade-up delay-1">
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Campus Coverage</h4>
                    <div class="stat-number">All Blocks</div>
                </div>
                <div class="stat-icon blue">
                    <i class="fa-solid fa-building"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Direct Routing</h4>
                    <div class="stat-number">Real-Time</div>
                </div>
                <div class="stat-icon amber">
                    <i class="fa-solid fa-bolt-lightning"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Live Updates</h4>
                    <div class="stat-number">Transparent</div>
                </div>
                <div class="stat-icon purple">
                    <i class="fa-solid fa-clock-rotate-left"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Target Resolution</h4>
                    <div class="stat-number">Quick Fix</div>
                </div>
                <div class="stat-icon green">
                    <i class="fa-solid fa-circle-check"></i>
                </div>
            </div>
        </section>

        <!-- How It Works / Roles Grid -->
        <section class="features-grid animate-fade-up delay-2">
            <div class="feature-card">
                <div class="feature-icon blue">
                    <i class="fa-solid fa-user-graduate"></i>
                </div>
                <h3>1. Students Report</h3>
                <p>
                    Lodge issues in seconds for Wi-Fi, classroom electricity, lab equipment, plumbing, or cleanliness with location & priority tags.
                </p>
                <a href="login.jsp" class="btn btn-sm btn-secondary" style="margin-top: 12px;">
                    Student Portal <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>

            <div class="feature-card">
                <div class="feature-icon purple">
                    <i class="fa-solid fa-user-shield"></i>
                </div>
                <h3>2. Admin Assigns</h3>
                <p>
                    College administrators review every submitted ticket, monitor campus-wide health, and assign qualified staff members right away.
                </p>
                <a href="login.jsp" class="btn btn-sm btn-secondary" style="margin-top: 12px;">
                    Admin Access <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>

            <div class="feature-card">
                <div class="feature-icon green">
                    <i class="fa-solid fa-helmet-safety"></i>
                </div>
                <h3>3. Staff Resolves</h3>
                <p>
                    Designated maintenance staff receive assigned tasks, inspect the site, update status to 'In Progress', and mark it 'Resolved'.
                </p>
                <a href="login.jsp" class="btn btn-sm btn-secondary" style="margin-top: 12px;">
                    Staff Workspace <i class="fa-solid fa-arrow-right"></i>
                </a>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer style="text-align: center; padding: 24px; color: #64748b; font-size: 13.5px; border-top: 1px solid #e2e8f0; background: #ffffff;">
        <p>&copy; 2026 CampusFix - College Problem Management System. All rights reserved.</p>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>
