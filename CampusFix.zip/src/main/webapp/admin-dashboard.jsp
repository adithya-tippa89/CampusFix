<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.campusfix.dao.ComplaintDAO" %>
<%@ page import="com.campusfix.dao.UserDAO" %>
<%@ page import="com.campusfix.dao.FeedbackDAO" %>
<%@ page import="com.campusfix.dao.NotificationDAO" %>
<%@ page import="com.campusfix.model.Complaint" %>
<%@ page import="com.campusfix.model.Staff" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="java.util.HashMap" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null || !"ADMIN".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    ComplaintDAO complaintDAO = new ComplaintDAO();
    List<Complaint> allComplaints = complaintDAO.getAllComplaints();

    UserDAO userDAO = new UserDAO();
    List<Staff> staffList = userDAO.getAllStaff();

    FeedbackDAO feedbackDAO = new FeedbackDAO();
    double avgRating = feedbackDAO.getAverageRating();

    int adminId = userDAO.getUserId(email);
    NotificationDAO notifDAO = new NotificationDAO();
    int unreadNotifs = (adminId != -1) ? notifDAO.getUnreadCount(adminId) : 0;

    int totalComplaints = (allComplaints != null) ? allComplaints.size() : 0;
    int pendingCount = 0;
    int activeCount = 0;
    int resolvedCount = 0;
    int highPriorityCount = 0;

    Map<String, Integer> categoryCounts = new HashMap<>();

    if (allComplaints != null) {
        for (Complaint c : allComplaints) {
            String s = c.getStatus();
            if ("PENDING".equalsIgnoreCase(s)) pendingCount++;
            else if ("ASSIGNED".equalsIgnoreCase(s) || "IN_PROGRESS".equalsIgnoreCase(s)) activeCount++;
            else if ("RESOLVED".equalsIgnoreCase(s)) resolvedCount++;

            if ("HIGH".equalsIgnoreCase(c.getPriority()) && !"RESOLVED".equalsIgnoreCase(s)) {
                highPriorityCount++;
            }

            String cat = c.getCategory() != null ? c.getCategory().toUpperCase() : "OTHER";
            categoryCounts.put(cat, categoryCounts.getOrDefault(cat, 0) + 1);
        }
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="admin-dashboard.jsp" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge" style="background: rgba(220, 38, 38, 0.25); border-color: #ef4444;">Admin</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <!-- Notification Bell -->
            <div class="notif-bell-container">
                <button type="button" class="btn-bell" onclick="toggleNotificationDropdown(event)" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <% if (unreadNotifs > 0) { %>
                        <span class="notif-badge-count"><%= unreadNotifs > 9 ? "9+" : unreadNotifs %></span>
                    <% } %>
                </button>
                <div id="notifDropdown" class="notif-dropdown">
                    <div class="notif-dropdown-header">
                        <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
                        <a href="notifications?action=readAll" style="font-size:12px; color:var(--primary); font-weight:600; text-decoration:none;">Mark all read</a>
                    </div>
                    <div id="notifDropdownList" class="notif-dropdown-body"></div>
                    <div class="notif-dropdown-footer">
                        <a href="notifications">View All Notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="user-profile-chip">
                <div class="user-avatar" style="background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%);">A</div>
                <span><%= email %></span>
            </div>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper">
        
        <!-- Welcome Banner -->
        <div class="page-header animate-fade-up">
            <div>
                <h1 class="page-header-title">
                    <i class="fa-solid fa-gauge-high" style="color: var(--primary);"></i>
                    Administrator Command Center
                </h1>
                <p class="page-header-desc">
                    Campus maintenance overview, ticket allocations, and real-time infrastructure status.
                </p>
            </div>
            <div style="display: flex; gap: 10px; align-items: center;">
                <span class="api-badge">
                    <i class="fa-solid fa-server" style="color:#2563eb;"></i> Spring REST: 
                    <a href="api/analytics/stats" target="_blank" style="color:var(--primary); font-weight:700;">/api/analytics/stats</a>
                </span>
                <a href="admin-complaints" class="btn btn-primary">
                    <i class="fa-solid fa-list-check"></i> Manage Complaints
                </a>
            </div>
        </div>

        <!-- Live Statistics Counter -->
        <section class="stats-banner animate-fade-up delay-1">
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Total Complaints</h4>
                    <div class="stat-number"><%= totalComplaints %></div>
                </div>
                <div class="stat-icon blue">
                    <i class="fa-solid fa-boxes-stacked"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Needs Assignment</h4>
                    <div class="stat-number" style="color: #d97706;"><%= pendingCount %></div>
                </div>
                <div class="stat-icon amber">
                    <i class="fa-solid fa-clock"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>In Progress / Active</h4>
                    <div class="stat-number" style="color: #7e22ce;"><%= activeCount %></div>
                </div>
                <div class="stat-icon purple">
                    <i class="fa-solid fa-screwdriver-wrench"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Student Satisfaction</h4>
                    <div class="stat-number" style="color: #eab308;">
                        <%= avgRating > 0 ? avgRating : "5.0" %> <span style="font-size:16px;">⭐</span>
                    </div>
                </div>
                <div class="stat-icon" style="background: #fef9c3; color: #ca8a04;">
                    <i class="fa-solid fa-star"></i>
                </div>
            </div>
        </section>

        <!-- High Priority Urgent Alert if any -->
        <% if (highPriorityCount > 0) { %>
            <div class="alert alert-error animate-fade-in">
                <i class="fa-solid fa-fire"></i>
                <span><strong>Attention Needed:</strong> There are <strong><%= highPriorityCount %> unresolved high-priority complaints</strong> requiring immediate technician assignment.</span>
            </div>
        <% } %>

        <!-- Future Implementation: Category Breakdown & Resolution Health -->
        <section class="detail-card animate-fade-up delay-2" style="padding: 24px 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px; flex-wrap: wrap; gap: 10px;">
                <div>
                    <h2 style="font-size: 18px; color: var(--secondary);">
                        <i class="fa-solid fa-chart-pie" style="color: var(--primary);"></i> Campus Infrastructure Health by Category
                    </h2>
                    <p style="font-size: 13px; color: var(--text-muted); margin-top: 2px;">Real-time breakdown of issue volume across college departments</p>
                </div>
                <div>
                    <span class="badge status-resolved">
                        <i class="fa-solid fa-circle-check"></i> Overall Resolution Rate: <%= totalComplaints > 0 ? (resolvedCount * 100 / totalComplaints) : 100 %>%
                    </span>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 18px;">
                <% 
                   String[] keyCats = {"ELECTRICAL", "WIFI", "WATER", "LAB", "CLASSROOM", "HOSTEL"};
                   for (String cat : keyCats) {
                       int cCount = categoryCounts.getOrDefault(cat, 0);
                       int pct = totalComplaints > 0 ? (cCount * 100 / totalComplaints) : 0;
                %>
                    <div style="background: #f8fafc; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 12px 16px;">
                        <div style="display: flex; justify-content: space-between; font-size: 13px; font-weight: 700; color: var(--secondary);">
                            <span><%= cat %></span>
                            <span style="color: var(--primary);"><%= cCount %> tickets (<%= pct %>%)</span>
                        </div>
                        <div class="progress-bar-container">
                            <div class="progress-bar-fill" style="width: <%= pct %>%;"></div>
                        </div>
                    </div>
                <% } %>
            </div>
        </section>

        <!-- Dashboard Action Cards -->
        <section class="dashboard-grid animate-fade-up delay-3">
            
            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#eff6ff; color:#2563eb;">
                    <i class="fa-solid fa-clipboard-list"></i>
                </div>
                <h2>All Campus Complaints</h2>
                <p>
                    Review, filter, inspect and assign all problems submitted by students across college departments and hostels.
                </p>
                <a href="admin-complaints" class="btn btn-primary">
                    <i class="fa-solid fa-table-list"></i> View All Complaints (<%= totalComplaints %>)
                </a>
            </div>

            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#f3e8ff; color:#7e22ce;">
                    <i class="fa-solid fa-user-gear"></i>
                </div>
                <h2>Maintenance Staff Directory</h2>
                <p>
                    <%= staffList != null ? staffList.size() : 0 %> registered maintenance staff personnel available for electrical, plumbing, Wi-Fi, and general repairs.
                </p>
                <a href="admin-complaints" class="btn btn-secondary">
                    <i class="fa-solid fa-user-check"></i> Assign Staff to Tickets
                </a>
            </div>

            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#dcfce7; color:#16a34a;">
                    <i class="fa-solid fa-code"></i>
                </div>
                <h2>Spring REST API Endpoints</h2>
                <p>
                    Enterprise RESTful API ready for mobile apps & integrations: <code>/api/complaints</code>, <code>/api/analytics/stats</code>, <code>/api/feedback</code>.
                </p>
                <a href="api/complaints" target="_blank" class="btn btn-secondary">
                    <i class="fa-solid fa-bolt"></i> Test REST JSON API
                </a>
            </div>

        </section>

    </main>

    <script src="js/main.js"></script>
</body>
</html>
