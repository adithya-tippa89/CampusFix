<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.campusfix.dao.UserDAO" %>
<%@ page import="com.campusfix.dao.ComplaintDAO" %>
<%@ page import="com.campusfix.dao.NotificationDAO" %>
<%@ page import="com.campusfix.model.Complaint" %>
<%@ page import="java.util.List" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null || !"STAFF".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    UserDAO userDAO = new UserDAO();
    int staffId = userDAO.getUserId(email);

    NotificationDAO notifDAO = new NotificationDAO();
    int unreadNotifs = (staffId != -1) ? notifDAO.getUnreadCount(staffId) : 0;

    ComplaintDAO complaintDAO = new ComplaintDAO();
    List<Complaint> assignedComplaints = (staffId != -1) ? complaintDAO.getComplaintsByStaff(staffId) : null;

    int totalAssigned = (assignedComplaints != null) ? assignedComplaints.size() : 0;
    int assignedCount = 0;
    int inProgressCount = 0;
    int resolvedCount = 0;

    if (assignedComplaints != null) {
        for (Complaint c : assignedComplaints) {
            String s = c.getStatus();
            if ("ASSIGNED".equalsIgnoreCase(s)) assignedCount++;
            else if ("IN_PROGRESS".equalsIgnoreCase(s)) inProgressCount++;
            else if ("RESOLVED".equalsIgnoreCase(s)) resolvedCount++;
        }
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="staff-dashboard.jsp" class="nav-brand">
            <div class="nav-logo-icon" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
                <i class="fa-solid fa-screwdriver-wrench"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge" style="background: rgba(16, 185, 129, 0.25); border-color: #10b981;">Staff</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <!-- Notification Bell -->
            <div class="notif-bell-container">
                <button type="button" class="btn-bell" onclick="toggleNotificationDropdown(event)" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <% if (unreadNotifs > 0) { %>
                        <span class="notif-badge-count"><%= unreadNotifs > 9 ? "9+" : unreadNotifs %></span>
                    <% } %>
                </button>
                <div id="notifDropdown" class="notif-dropdown">
                    <div class="notif-dropdown-header">
                        <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
                        <a href="notifications?action=readAll" style="font-size:12px; color:var(--primary); font-weight:600; text-decoration:none;">Mark all read</a>
                    </div>
                    <div id="notifDropdownList" class="notif-dropdown-body"></div>
                    <div class="notif-dropdown-footer">
                        <a href="notifications">View All Notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="user-profile-chip">
                <div class="user-avatar" style="background: linear-gradient(135deg, #10b981 0%, #047857 100%);">S</div>
                <span><%= email %></span>
            </div>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper">
        
        <!-- Welcome Section -->
        <div class="page-header animate-fade-up">
            <div>
                <h1 class="page-header-title">
                    <i class="fa-solid fa-helmet-safety" style="color: #10b981;"></i>
                    Maintenance Staff Workspace
                </h1>
                <p class="page-header-desc">
                    View assigned repairs, report work status, and keep college facilities operational.
                </p>
            </div>
            <div>
                <a href="staff-complaints" class="btn btn-primary">
                    <i class="fa-solid fa-list-check"></i> View Assigned Work (<%= totalAssigned %>)
                </a>
            </div>
        </div>

        <!-- Live Statistics Counter -->
        <section class="stats-banner animate-fade-up delay-1">
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Assigned Work Orders</h4>
                    <div class="stat-number"><%= totalAssigned %></div>
                </div>
                <div class="stat-icon blue">
                    <i class="fa-solid fa-clipboard-list"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Awaiting Start</h4>
                    <div class="stat-number" style="color: #2563eb;"><%= assignedCount %></div>
                </div>
                <div class="stat-icon amber">
                    <i class="fa-solid fa-bell"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>In Progress</h4>
                    <div class="stat-number" style="color: #7e22ce;"><%= inProgressCount %></div>
                </div>
                <div class="stat-icon purple">
                    <i class="fa-solid fa-person-digging"></i>
                </div>
            </div>
            <div class="stat-box">
                <div class="stat-info">
                    <h4>Completed & Resolved</h4>
                    <div class="stat-number" style="color: #16a34a;"><%= resolvedCount %></div>
                </div>
                <div class="stat-icon green">
                    <i class="fa-solid fa-circle-check"></i>
                </div>
            </div>
        </section>

        <!-- Dashboard Action Cards -->
        <section class="dashboard-grid animate-fade-up delay-2">
            
            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#eff6ff; color:#2563eb;">
                    <i class="fa-solid fa-wrench"></i>
                </div>
                <h2>My Assigned Complaints</h2>
                <p>
                    Review the campus tickets delegated to you by the administration. Inspect problem titles, descriptions, and room locations.
                </p>
                <a href="staff-complaints" class="btn btn-primary">
                    <i class="fa-solid fa-arrow-right"></i> Open Assigned List
                </a>
            </div>

            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#f3e8ff; color:#7e22ce;">
                    <i class="fa-solid fa-pen-to-square"></i>
                </div>
                <h2>Update Task Status</h2>
                <p>
                    Set tickets to 'In Progress' when arriving at the site, and mark them 'Resolved' once the physical fix is complete.
                </p>
                <a href="staff-complaints" class="btn btn-secondary">
                    <i class="fa-solid fa-arrows-rotate"></i> Update Work Status
                </a>
            </div>

            <div class="dash-card">
                <div class="card-icon-wrapper" style="background:#dcfce7; color:#16a34a;">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <h2>Maintenance Protocol</h2>
                <p>
                    Ensure electrical and plumbing safety standards are maintained. Coordinate with department heads for lab access when needed.
                </p>
                <a href="staff-complaints" class="btn btn-secondary">
                    <i class="fa-solid fa-list-check"></i> Check Active Tasks
                </a>
            </div>

        </section>

    </main>

    <script src="js/main.js"></script>
</body>
</html>
