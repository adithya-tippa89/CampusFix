<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.campusfix.model.Complaint" %>
<%@ page import="com.campusfix.model.Staff" %>
<%@ page import="com.campusfix.dao.FeedbackDAO" %>
<%@ page import="com.campusfix.dao.NotificationDAO" %>
<%@ page import="com.campusfix.model.Feedback" %>
<%@ page import="java.util.List" %>
<%@ page import="java.text.SimpleDateFormat" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null || !"ADMIN".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    Complaint complaint = (Complaint) request.getAttribute("complaint");
    List<Staff> staffList = (List<Staff>) request.getAttribute("staffList");

    if (complaint == null) {
        response.sendRedirect("admin-complaints");
        return;
    }

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
    String status = complaint.getStatus() != null ? complaint.getStatus().toUpperCase() : "PENDING";
    String priority = complaint.getPriority() != null ? complaint.getPriority().toUpperCase() : "MEDIUM";
    String statusClass = "status-" + status.toLowerCase().replace("_", "-");
    String priorityClass = "priority-" + priority.toLowerCase();

    FeedbackDAO feedbackDAO = new FeedbackDAO();
    Feedback studentFeedback = feedbackDAO.getFeedbackByComplaintId(complaint.getId());

    int unreadNotifs = 0;
    try {
        unreadNotifs = new NotificationDAO().getUnreadCountByEmail(email);
    } catch (Exception ignored) {}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint Details CF-<%= complaint.getId() %> - CampusFix</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="admin-dashboard.jsp" class="nav-brand">
            <div class="nav-logo-icon">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge" style="background: rgba(220, 38, 38, 0.25); border-color: #ef4444;">Admin</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <!-- Notification Bell -->
            <div class="notif-bell-container">
                <button type="button" class="btn-bell" onclick="toggleNotificationDropdown(event)" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <% if (unreadNotifs > 0) { %>
                        <span class="notif-badge-count"><%= unreadNotifs > 9 ? "9+" : unreadNotifs %></span>
                    <% } %>
                </button>
                <div id="notifDropdown" class="notif-dropdown">
                    <div class="notif-dropdown-header">
                        <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
                        <a href="notifications?action=readAll" style="font-size:12px; color:var(--primary); font-weight:600; text-decoration:none;">Mark all read</a>
                    </div>
                    <div id="notifDropdownList" class="notif-dropdown-body"></div>
                    <div class="notif-dropdown-footer">
                        <a href="notifications">View All Notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <a href="admin-complaints" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-arrow-left"></i> All Complaints
            </a>
            <div class="user-profile-chip">
                <div class="user-avatar" style="background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%);">A</div>
                <span><%= email %></span>
            </div>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper" style="max-width: 900px;">
        
        <div class="page-header animate-fade-up">
            <div>
                <div style="font-size: 13px; color: var(--text-muted); margin-bottom: 6px;">
                    <a href="admin-dashboard.jsp" style="color: var(--primary); text-decoration: none;">Dashboard</a> &gt; 
                    <a href="admin-complaints" style="color: var(--primary); text-decoration: none;">Complaints</a> &gt; 
                    <span>CF-<%= complaint.getId() %></span>
                </div>
                <h1 class="page-header-title">
                    <span class="complaint-id-tag" style="font-size: 20px;">CF-<%= complaint.getId() %></span>
                    <%= complaint.getTitle() %>
                </h1>
            </div>
            <div>
                <span class="badge <%= statusClass %>" style="font-size: 14px; padding: 6px 14px;">
                    <span class="badge-dot"></span>
                    <%= status.replace("_", " ") %>
                </span>
            </div>
        </div>

        <!-- Success & Error Alerts -->
        <% if ("true".equals(request.getParameter("success"))) { %>
            <div class="alert alert-success animate-fade-in">
                <i class="fa-solid fa-circle-check"></i>
                <span><strong>Assignment Successful!</strong> The complaint ticket has been assigned to the selected staff member.</span>
            </div>
        <% } %>

        <% if ("true".equals(request.getParameter("error"))) { %>
            <div class="alert alert-error animate-fade-in">
                <i class="fa-solid fa-circle-exclamation"></i>
                <span>Failed to assign complaint. Please choose a valid staff member and try again.</span>
            </div>
        <% } %>

        <!-- Complaint Details Card -->
        <div class="detail-card animate-fade-up delay-1">
            
            <div class="detail-header">
                <div>
                    <h2 style="font-size: 18px; color: var(--secondary);">Complaint Specifications</h2>
                    <p style="font-size: 13px; color: var(--text-muted); margin-top: 2px;">
                        Reported on <%= complaint.getCreatedAt() != null ? dateFormat.format(complaint.getCreatedAt()) : "N/A" %>
                    </p>
                </div>
                <div>
                    <span class="badge <%= priorityClass %>">
                        <% if ("HIGH".equals(priority)) { %>
                            <i class="fa-solid fa-fire"></i>
                        <% } else if ("MEDIUM".equals(priority)) { %>
                            <i class="fa-solid fa-triangle-exclamation"></i>
                        <% } else { %>
                            <i class="fa-solid fa-circle-info"></i>
                        <% } %>
                        <%= priority %> PRIORITY (Target SLA: <%= "HIGH".equals(priority) ? "24h" : ("MEDIUM".equals(priority) ? "48h" : "72h") %>)
                    </span>
                </div>
            </div>

            <div class="detail-grid">
                <div class="detail-item">
                    <div class="detail-item-label">
                        <i class="fa-solid fa-user-graduate"></i> Student ID
                    </div>
                    <div class="detail-item-value">#<%= complaint.getStudentId() %></div>
                </div>

                <div class="detail-item">
                    <div class="detail-item-label">
                        <i class="fa-solid fa-layer-group"></i> Category
                    </div>
                    <div class="detail-item-value"><%= complaint.getCategory() %></div>
                </div>

                <div class="detail-item">
                    <div class="detail-item-label">
                        <i class="fa-solid fa-location-dot"></i> Campus Location
                    </div>
                    <div class="detail-item-value"><%= complaint.getLocation() %></div>
                </div>

                <div class="detail-item">
                    <div class="detail-item-label">
                        <i class="fa-solid fa-user-gear"></i> Assigned Staff ID
                    </div>
                    <div class="detail-item-value">
                        <%= complaint.getAssignedTo() > 0 ? ("Staff #" + complaint.getAssignedTo()) : "Not Assigned Yet" %>
                    </div>
                </div>
            </div>

            <div>
                <div class="detail-item-label" style="margin-bottom: 8px;">
                    <i class="fa-solid fa-align-left"></i> Problem Description
                </div>
                <div class="detail-description-box">
                    <p style="font-size: 14.5px; line-height: 1.7; color: var(--secondary); white-space: pre-wrap;"><%= complaint.getDescription() %></p>
                </div>
            </div>

        </div>

        <!-- Future Feature: Student Feedback & Review Card (if rated) -->
        <% if (studentFeedback != null) { %>
            <div class="detail-card animate-fade-up delay-1" style="border-left: 4px solid #f59e0b;">
                <h2 style="font-size: 18px; color: var(--secondary); margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                    <i class="fa-solid fa-star" style="color: #f59e0b;"></i> Student Rating & Feedback
                </h2>
                <div style="font-size: 16px; font-weight: 700; color: #b45309; margin-bottom: 8px;">
                    <% for (int s = 1; s <= 5; s++) { %>
                        <i class="fa-<%= (s <= studentFeedback.getRating()) ? "solid" : "regular" %> fa-star" style="color:#f59e0b;"></i>
                    <% } %>
                    <span style="margin-left: 8px;"><%= studentFeedback.getRating() %> / 5 Stars</span>
                </div>
                <% if (studentFeedback.getComments() != null && !studentFeedback.getComments().trim().isEmpty()) { %>
                    <div class="detail-description-box" style="background: #fffbeb; border-color: #fef08a;">
                        <p style="font-style: italic; color: #78350f;">"<%= studentFeedback.getComments() %>"</p>
                    </div>
                <% } %>
            </div>
        <% } %>

        <!-- Staff Assignment Card -->
        <div class="detail-card animate-fade-up delay-2">
            <h2 style="font-size: 18px; color: var(--secondary); margin-bottom: 6px;">
                <i class="fa-solid fa-user-plus" style="color: var(--primary);"></i>
                Assign Maintenance Personnel
            </h2>
            <p style="font-size: 13.5px; color: var(--text-muted); margin-bottom: 20px;">
                Delegate this ticket to a technician or supervisor. They will receive the notification on their staff portal.
            </p>

            <% if (staffList == null || staffList.isEmpty()) { %>
                <div class="alert alert-info">
                    <i class="fa-solid fa-info-circle"></i>
                    <span>No maintenance staff members are registered in the system yet.</span>
                </div>
            <% } else { %>
                <form action="assign-complaint" method="post">
                    <input type="hidden" name="complaintId" value="<%= complaint.getId() %>">

                    <div class="form-group">
                        <label class="form-label" for="staffId">
                            <i class="fa-solid fa-helmet-safety"></i> Choose Maintenance Staff Member
                        </label>
                        <select name="staffId" id="staffId" class="form-control" required>
                            <option value="" disabled selected>-- Select Qualified Staff Member --</option>
                            <% for (Staff staff : staffList) { %>
                                <option value="<%= staff.getId() %>" <%= (complaint.getAssignedTo() == staff.getId()) ? "selected" : "" %>>
                                    <%= staff.getName() %> (<%= staff.getEmail() %>) - ID #<%= staff.getId() %>
                                </option>
                            <% } %>
                        </select>
                    </div>

                    <div style="display: flex; gap: 12px; margin-top: 14px;">
                        <button type="submit" class="btn btn-primary" style="padding: 12px 24px;">
                            <i class="fa-solid fa-paper-plane"></i> Assign & Update Status
                        </button>
                        <a href="admin-complaints" class="btn btn-secondary">
                            Back to Complaints List
                        </a>
                    </div>
                </form>
            <% } %>
        </div>

    </main>

    <script src="js/main.js"></script>
</body>
</html>
