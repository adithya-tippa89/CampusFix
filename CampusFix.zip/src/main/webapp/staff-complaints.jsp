<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="com.campusfix.model.Complaint" %>
<%@ page import="com.campusfix.dao.NotificationDAO" %>
<%@ page import="java.text.SimpleDateFormat" %>

<%
    String email = (String) session.getAttribute("email");
    String role = (String) session.getAttribute("role");

    if (email == null || !"STAFF".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }

    List<Complaint> complaints = (List<Complaint>) request.getAttribute("complaints");
    if (complaints == null) {
        response.sendRedirect("staff-complaints");
        return;
    }

    SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM, hh:mm a");
    int unreadNotifs = 0;
    try {
        unreadNotifs = new NotificationDAO().getUnreadCountByEmail(email);
    } catch (Exception ignored) {}
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assigned Work Orders - CampusFix Staff</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Header Navigation -->
    <header class="navbar">
        <a href="staff-dashboard.jsp" class="nav-brand">
            <div class="nav-logo-icon" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
                <i class="fa-solid fa-screwdriver-wrench"></i>
            </div>
            <div>
                <div class="nav-title">
                    CampusFix
                    <span class="nav-badge" style="background: rgba(16, 185, 129, 0.25); border-color: #10b981;">Staff</span>
                </div>
            </div>
        </a>
        <div class="nav-actions">
            <!-- Notification Bell -->
            <div class="notif-bell-container">
                <button type="button" class="btn-bell" onclick="toggleNotificationDropdown(event)" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    <% if (unreadNotifs > 0) { %>
                        <span class="notif-badge-count"><%= unreadNotifs > 9 ? "9+" : unreadNotifs %></span>
                    <% } %>
                </button>
                <div id="notifDropdown" class="notif-dropdown">
                    <div class="notif-dropdown-header">
                        <h4><i class="fa-solid fa-bell"></i> Notifications</h4>
                        <a href="notifications?action=readAll" style="font-size:12px; color:var(--primary); font-weight:600; text-decoration:none;">Mark all read</a>
                    </div>
                    <div id="notifDropdownList" class="notif-dropdown-body"></div>
                    <div class="notif-dropdown-footer">
                        <a href="notifications">View All Notifications <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <a href="staff-dashboard.jsp" class="btn-nav btn-nav-outline">
                <i class="fa-solid fa-house"></i> Dashboard
            </a>
            <div class="user-profile-chip">
                <div class="user-avatar" style="background: linear-gradient(135deg, #10b981 0%, #047857 100%);">S</div>
                <span><%= email %></span>
            </div>
            <a href="logout" class="btn-nav btn-logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i> Logout
            </a>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-wrapper">
        
        <div class="page-header animate-fade-up">
            <div>
                <h1 class="page-header-title">
                    <i class="fa-solid fa-screwdriver-wrench" style="color: #10b981;"></i>
                    My Assigned Work Orders
                </h1>
                <p class="page-header-desc">
                    Complaints assigned to you by the administrator. Click 'Manage' to update progress or mark resolved.
                </p>
            </div>
            <div>
                <a href="staff-dashboard.jsp" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>

        <% if (complaints.isEmpty()) { %>
            
            <div class="table-card empty-state animate-fade-scale">
                <div class="empty-icon">
                    <i class="fa-solid fa-mug-hot"></i>
                </div>
                <h3>No Assigned Complaints</h3>
                <p>You have no pending maintenance tasks assigned right now. Enjoy your break!</p>
                <a href="staff-dashboard.jsp" class="btn btn-secondary">
                    Return to Dashboard
                </a>
            </div>

        <% } else { %>

            <div class="table-card animate-fade-up delay-1">
                
                <!-- Table Search & Filter Bar -->
                <div class="table-toolbar">
                    <div class="input-icon-group" style="margin-bottom: 0;">
                        <input type="text" 
                               id="tableSearch" 
                               class="table-search-input" 
                               placeholder="Search title, category, location, ID...">
                        <i class="fa-solid fa-magnifying-glass input-icon"></i>
                    </div>

                    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                        <button type="button" class="btn btn-sm btn-secondary filter-btn active" data-status="all">All (<%= complaints.size() %>)</button>
                        <button type="button" class="btn btn-sm btn-secondary filter-btn" data-status="assigned">Assigned</button>
                        <button type="button" class="btn btn-sm btn-secondary filter-btn" data-status="in_progress">In Progress</button>
                        <button type="button" class="btn btn-sm btn-secondary filter-btn" data-status="resolved">Resolved</button>
                    </div>
                </div>

                <!-- Table Content -->
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Ticket ID</th>
                                <th>Problem Details</th>
                                <th>Category</th>
                                <th>Location</th>
                                <th>Priority</th>
                                <th>Current Status</th>
                                <th>Reported</th>
                                <th style="text-align: right;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% for (Complaint complaint : complaints) { 
                                String status = complaint.getStatus() != null ? complaint.getStatus().toUpperCase() : "ASSIGNED";
                                String priority = complaint.getPriority() != null ? complaint.getPriority().toUpperCase() : "MEDIUM";
                                String statusClass = "status-" + status.toLowerCase().replace("_", "-");
                                String priorityClass = "priority-" + priority.toLowerCase();
                            %>
                            <tr>
                                <td>
                                    <span class="complaint-id-tag">CF-<%= complaint.getId() %></span>
                                </td>
                                <td>
                                    <div style="font-weight: 700; color: var(--secondary);"><%= complaint.getTitle() %></div>
                                    <% if (complaint.getDescription() != null && !complaint.getDescription().isEmpty()) { 
                                        String descSnippet = complaint.getDescription();
                                        if (descSnippet.length() > 60) {
                                            descSnippet = descSnippet.substring(0, 60) + "...";
                                        }
                                    %>
                                        <div style="font-size: 12.5px; color: var(--text-muted); margin-top: 2px;"><%= descSnippet %></div>
                                    <% } %>
                                </td>
                                <td>
                                    <span class="category-pill">
                                        <i class="fa-solid fa-tag"></i> <%= complaint.getCategory() %>
                                    </span>
                                </td>
                                <td>
                                    <span style="font-weight: 500; font-size: 13.5px;">
                                        <i class="fa-solid fa-location-dot" style="color: var(--text-muted); margin-right: 4px;"></i>
                                        <%= complaint.getLocation() %>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <%= priorityClass %>">
                                        <% if ("HIGH".equals(priority)) { %>
                                            <i class="fa-solid fa-fire"></i>
                                        <% } else if ("MEDIUM".equals(priority)) { %>
                                            <i class="fa-solid fa-triangle-exclamation"></i>
                                        <% } else { %>
                                            <i class="fa-solid fa-circle-info"></i>
                                        <% } %>
                                        <%= priority %>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge <%= statusClass %>">
                                        <span class="badge-dot"></span>
                                        <%= status.replace("_", " ") %>
                                    </span>
                                </td>
                                <td style="color: var(--text-muted); font-size: 13px; white-space: nowrap;">
                                    <% if (complaint.getCreatedAt() != null) { %>
                                        <%= dateFormat.format(complaint.getCreatedAt()) %>
                                    <% } else { %>
                                        --
                                    <% } %>
                                </td>
                                <td style="text-align: right;">
                                    <a href="staff-complaint?id=<%= complaint.getId() %>" class="btn btn-sm btn-primary">
                                        <i class="fa-solid fa-pen-to-square"></i> Manage
                                    </a>
                                </td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>

            </div>

        <% } %>

    </main>

    <script src="js/main.js"></script>
</body>
</html>
