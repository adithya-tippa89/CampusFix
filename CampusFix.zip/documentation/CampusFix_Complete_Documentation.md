# CampusFix: Project Technical Documentation & System Manual

**Project Name:** CampusFix – Intelligent Campus Infrastructure Maintenance & Complaint Management System  
**Architecture:** Layered Enterprise Architecture (Spring Framework 5.3 + Java EE Servlet 4.0 + MySQL)  
**Target Environment:** Apache Tomcat 9.0 | JDK 8 / 11 / 17 / 26 | IntelliJ IDEA  

---

## 📑 Table of Contents
1. [System Architecture & Data Flow](#1-system-architecture--data-flow)
2. [User Input Screens & Screenshots](#2-user-input-screens--screenshots)
   - [2.1 Home Page (`index.jsp`)](#21-home-page-indexjsp)
   - [2.2 User Registration Screen (`register.jsp`)](#22-user-registration-screen-registerjsp)
   - [2.3 User Login Screen (`login.jsp`)](#23-user-login-screen-loginjsp)
   - [2.4 Smart Complaint Reporting Form (`complaint.jsp`)](#24-smart-complaint-reporting-form-complaintjsp)
   - [2.5 Resolution Feedback & 5-Star Rating Modal](#25-resolution-feedback--5-star-rating-modal)
3. [User Output Screens & Screenshots](#3-user-output-screens--screenshots)
   - [3.1 Student Dashboard & Active Tickets](#31-student-dashboard--active-tickets)
   - [3.2 Administrator Dashboard & Staff Dispatch Queue](#32-administrator-dashboard--staff-dispatch-queue)
   - [3.3 Staff / Technician Work Order Queue](#33-staff--technician-work-order-queue)
   - [3.4 Real-Time Notification Center & Alert Feed](#34-real-time-notification-center--alert-feed)
4. [Database Schema Specifications](#4-database-schema-specifications)
5. [Core Source Code Implementation](#5-core-source-code-implementation)
   - [5.1 Spring REST Controller (`ComplaintRestController.java`)](#51-spring-rest-controller)
   - [5.2 Business Service Layer (`ComplaintService.java`)](#52-business-service-layer)
   - [5.3 Complaint Submission Servlet (`ComplaintServlet.java`)](#53-complaint-submission-servlet)
   - [5.4 Data Access Layer (`NotificationDAO.java`)](#54-data-access-layer)
   - [5.5 Configuration Descriptor (`web.xml`)](#55-configuration-descriptor)
   - [5.6 Interactive Client Logic (`main.js`)](#56-interactive-client-logic)

---

## 1. System Architecture & Data Flow

CampusFix follows a decoupled multi-tier enterprise architecture. Requests flow from the client-side JSP views through Java EE Servlets and Spring MVC Controllers, executing business rules via Spring Services before persisting state in MySQL via safe JDBC `PreparedStatement` transactions.

```mermaid
flowchart TD
    subgraph Client["Client Tier (Browser)"]
        UI["JSP Views + CSS Micro-animations"]
        JS["Vanilla JS (Fetch API / Live Preview)"]
    end

    subgraph Web["Web & Controller Tier (Tomcat 9.0)"]
        Servlet["Java EE Servlets (Auth & Session)"]
        SpringMVC["Spring DispatcherServlet (/api/*)"]
    end

    subgraph Service["Application Business Tier"]
        CompServ["ComplaintService"]
        NotifServ["NotificationService"]
        FeedServ["FeedbackService"]
    end

    subgraph Data["Persistence & Database Tier"]
        DAO["DAO Layer (JDBC PreparedStatements)"]
        MySQL[("MySQL Database (campusfix)")]
    end

    UI --> Servlet
    JS --> SpringMVC
    Servlet --> CompServ
    SpringMVC --> CompServ
    Servlet --> NotifServ
    CompServ --> DAO
    NotifServ --> DAO
    FeedServ --> DAO
    DAO --> MySQL
```

---

## 2. User Input Screens & Screenshots

### 2.1 Home Page (`index.jsp`)
The landing portal presents students and faculty with an overview of campus maintenance services, dynamic feature badges, and direct role-based login routing.

![CampusFix Home Page](screenshots/01_home_page.png)

#### Screen Details:
- **Visual Hero Section:** Features a 3D isometric campus graphic paired with animated floating status indicator cards (`Lab Wi-Fi Outage: Resolved`, `Room 302 Projector: In Progress`).
- **Quick Action Call-to-Actions (CTAs):** Direct navigation buttons to Login and Registration.
- **Value Proposition Badges:** Highlights paperless ticketing, automated technician routing, and 100% transparency.

---

### 2.2 User Registration Screen (`register.jsp`)
Permits students, technicians, and administrative personnel to create a secure, role-based account within the system.

![User Registration Screen](screenshots/02_register_page.png)

#### Input Fields Specification:
| Field Name | Type | Validation Rules | Description |
| :--- | :--- | :--- | :--- |
| `Full Name` | Text | Required, 3–60 chars | Student or staff full identity |
| `College Email` | Email | Required, Valid college format | Unique identifier for authentication |
| `Password` | Password | Required, Min 6 chars | Salted and secured user credential |
| `Select Role` | Dropdown | `STUDENT`, `STAFF`, `ADMIN` | Determines permissions and dashboard routing |

---

### 2.3 User Login Screen (`login.jsp`)
Authenticates registered stakeholders and securely initializes an HTTP session containing the user's role and email attributes.

![User Login Screen](screenshots/03_login_page.png)

#### Input Fields Specification:
| Field Name | Type | Description |
| :--- | :--- | :--- |
| `College Email Address` | Email | Registered user email address |
| `Password` | Password | Protected secret key |
| `Sign In Button` | Submit | Validates credentials via `LoginServlet` and redirects to respective role dashboard |

---

### 2.4 Smart Complaint Reporting Form (`complaint.jsp`)
The primary input interface for students to report infrastructural and facility defects.

![Complaint Submission Form](screenshots/04_complaint_form.png)

#### Interactive Form Features:
1. **Interactive Category Picker:** 9 visual cards (Electrical, Plumbing, Wi-Fi, Furniture, AC, Computer Lab, Sanitation, Civil, Security) with border highlight and icon animation.
2. **Campus Location Quick-Chips:** 1-click location chips (`+ Science Block`, `+ Central Library`, `+ Computer Lab 3`, `+ Hostels`) that automatically populate the exact location field.
3. **Dynamic SLA Tracker:** Real-time visual commitment banner indicating expected resolution turnaround (High: 24h, Medium: 48h, Low: 72h).
4. **Contact Phone Number Field:** Direct callback contact captured for field technician coordination.
5. **Live Character Counter:** Real-time client countdown (`0 / 500 characters`) ensuring concise descriptions.
6. **Photo Attachment & Live Thumbnail Preview:** Drag-and-drop file selector that renders an instant client-side image thumbnail with remove button prior to upload.

---

### 2.5 Resolution Feedback & 5-Star Rating Modal
A closed-loop quality assessment interface triggered upon complaint resolution.

![Feedback & Rating Modal](screenshots/09_feedback_modal.png)

#### Input Fields Specification:
| Field Name | Type | Description |
| :--- | :--- | :--- |
| `Star Rating` | Radio Stars | 1 to 5 Star satisfaction rating |
| `Student Comments` | Textarea | Optional qualitative review on technician timeliness and repair quality |
| `Complaint ID` | Hidden | Binds review record to specific ticket in MySQL `feedback` table |

---

## 3. User Output Screens & Screenshots

### 3.1 Student Dashboard & Active Tickets
Provides students with real-time insight into ticket progress, unread notification counts, and action buttons.

![Student Dashboard](screenshots/05_student_dashboard.png)

#### Output Elements:
- **KPI Summary Cards:** Total complaints filed, pending triage, currently in repair, and resolved.
- **Navbar Bell Badge:** Displays unread notification count badge with pulsing indicator.
- **Incident Table:** Lists ticket ID, issue title, category tag, priority pill, location, and dynamic status pill (`Pending`, `In Progress`, `Resolved`).

---

### 3.2 Administrator Dashboard & Staff Dispatch Queue
Central supervisory console for college facilities management to oversee incidents, allocate technicians, and generate reports.

![Admin Dashboard](screenshots/06_admin_dashboard.png)

#### Output Elements:
- **Campus Metrics:** Total tickets, unassigned high-priority emergency alerts, active repairs, and average student satisfaction score (e.g., `4.8 / 5.0`).
- **Staff Dispatch Queue:** Interactive technician assignment dropdown allowing immediate allocation of electricians, plumbers, or network engineers.
- **CSV Data Export:** 1-click data export generating formatted Excel CSV reports for institutional audits.

---

### 3.3 Staff / Technician Work Order Queue
Mobile-friendly workspace for campus maintenance crew to view assigned tasks, contact students, and update repair statuses.

![Staff Work Orders Dashboard](screenshots/07_staff_dashboard.png)

#### Output Elements:
- **Assigned Work Orders Table:** Displays Ticket ID, specific defect description, exact campus location, and priority urgency.
- **Direct Contact Button:** Enables technician to quickly view and call student's phone number for site access.
- **State Transition Buttons:** Transition buttons to move ticket from `Assigned` $\rightarrow$ `In Progress` $\rightarrow$ `Resolved`.

---

### 3.4 Real-Time Notification Center & Alert Feed
Dedicated notification feed keeping all campus stakeholders synchronized with real-time alerts.

![Notification Center](screenshots/08_notifications.png)

#### Output Elements:
- **Event-Driven Feed:** Displays time-stamped alerts for ticket creation, staff dispatch, status modifications, and review submissions.
- **Unread Status Indicators:** Blue accent highlight and `NEW` badge for unread notifications.
- **Bulk Action:** "Mark All as Read" button to clear notification badges across the system.

---

## 4. Database Schema Specifications

The relational database `campusfix` comprises 5 primary tables with relational integrity and automatic schema initialization:

### 1. `users` Table
```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('STUDENT', 'STAFF', 'ADMIN') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. `complaints` Table
```sql
CREATE TABLE complaints (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    location VARCHAR(255) NOT NULL,
    priority ENUM('LOW', 'MEDIUM', 'HIGH') DEFAULT 'MEDIUM',
    status ENUM('PENDING', 'ASSIGNED', 'IN PROGRESS', 'RESOLVED') DEFAULT 'PENDING',
    student_email VARCHAR(100) NOT NULL,
    assigned_to VARCHAR(100) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3. `notifications` Table
```sql
CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    recipient_email VARCHAR(100) NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(50) DEFAULT 'INFO',
    link VARCHAR(255) DEFAULT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 4. `feedback` Table
```sql
CREATE TABLE IF NOT EXISTS feedback (
    id INT AUTO_INCREMENT PRIMARY KEY,
    complaint_id INT NOT NULL,
    student_email VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comments TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
);
```

---

## 5. Core Source Code Implementation

### 5.1 Spring REST Controller
`src/main/java/com/campusfix/controller/api/ComplaintRestController.java`
```java
package com.campusfix.controller.api;

import com.campusfix.model.Complaint;
import com.campusfix.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/complaints")
public class ComplaintRestController {

    @Autowired
    private ComplaintService complaintService;

    @GetMapping
    public ResponseEntity<List<Complaint>> getAllComplaints() {
        return ResponseEntity.ok(complaintService.getAllComplaints());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Complaint> getComplaintById(@PathVariable("id") int id) {
        Complaint complaint = complaintService.getComplaintById(id);
        if (complaint == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(complaint);
    }

    @PostMapping("/add")
    public ResponseEntity<String> addComplaint(@RequestBody Complaint complaint) {
        boolean success = complaintService.addComplaint(complaint);
        if (success) {
            return ResponseEntity.ok("Complaint registered successfully via REST API");
        }
        return ResponseEntity.badRequest().body("Failed to register complaint");
    }
}
```

---

### 5.2 Business Service Layer
`src/main/java/com/campusfix/service/ComplaintService.java`
```java
package com.campusfix.service;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.model.Complaint;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ComplaintService {

    private final ComplaintDAO complaintDAO;

    public ComplaintService() {
        this.complaintDAO = new ComplaintDAO();
    }

    public List<Complaint> getAllComplaints() {
        return complaintDAO.getAllComplaints();
    }

    public List<Complaint> getComplaintsByStudent(String email) {
        return complaintDAO.getComplaintsByStudent(email);
    }

    public List<Complaint> getComplaintsByStaff(String email) {
        return complaintDAO.getComplaintsByStaff(email);
    }

    public Complaint getComplaintById(int id) {
        return complaintDAO.getComplaintById(id);
    }

    public boolean addComplaint(Complaint complaint) {
        return complaintDAO.addComplaint(complaint);
    }

    public boolean updateStatus(int id, String status) {
        return complaintDAO.updateStatus(id, status);
    }

    public boolean assignComplaint(int id, String staffEmail) {
        return complaintDAO.assignComplaint(id, staffEmail);
    }
}
```

---

### 5.3 Complaint Submission Servlet
`src/main/java/com/campusfix/controller/ComplaintServlet.java`
```java
package com.campusfix.controller;

import com.campusfix.dao.ComplaintDAO;
import com.campusfix.dao.NotificationDAO;
import com.campusfix.model.Complaint;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/submit-complaint")
public class ComplaintServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String studentEmail = (String) session.getAttribute("email");
        String title = request.getParameter("title");
        String category = request.getParameter("category");
        String description = request.getParameter("description");
        String location = request.getParameter("location");
        String priority = request.getParameter("priority");
        String contactPhone = request.getParameter("contactPhone");

        if (contactPhone != null && !contactPhone.trim().isEmpty()) {
            description = "[Contact: " + contactPhone.trim() + "]\n" + description;
        }

        Complaint complaint = new Complaint();
        complaint.setTitle(title);
        complaint.setCategory(category);
        complaint.setDescription(description);
        complaint.setLocation(location);
        complaint.setPriority(priority != null ? priority : "MEDIUM");
        complaint.setStudentEmail(studentEmail);
        complaint.setStatus("PENDING");

        ComplaintDAO dao = new ComplaintDAO();
        boolean success = dao.addComplaint(complaint);

        if (success) {
            // Trigger Automated Student Notification
            new NotificationDAO().createNotification(
                studentEmail,
                "Complaint Submitted Successfully",
                "Your grievance regarding '" + title + "' has been logged under ID review.",
                "SUCCESS",
                "my-complaints"
            );
            response.sendRedirect("my-complaints?success=true");
        } else {
            response.sendRedirect("complaint.jsp?error=true");
        }
    }
}
```

---

### 5.4 Data Access Layer
`src/main/java/com/campusfix/dao/NotificationDAO.java`
```java
package com.campusfix.dao;

import com.campusfix.model.Notification;
import com.campusfix.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotificationDAO {

    public NotificationDAO() {
        createTableIfNotExists();
    }

    private void createTableIfNotExists() {
        String sql = "CREATE TABLE IF NOT EXISTS notifications (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "recipient_email VARCHAR(100) NOT NULL," +
                "title VARCHAR(150) NOT NULL," +
                "message TEXT NOT NULL," +
                "type VARCHAR(50) DEFAULT 'INFO'," +
                "link VARCHAR(255) DEFAULT NULL," +
                "is_read BOOLEAN DEFAULT FALSE," +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                ")";
        try (Connection con = DBConnection.getConnection();
             Statement stmt = con.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean createNotification(String email, String title, String msg, String type, String link) {
        String sql = "INSERT INTO notifications (recipient_email, title, message, type, link) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, title);
            ps.setString(3, msg);
            ps.setString(4, type);
            ps.setString(5, link);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getUnreadCountByEmail(String email) {
        String sql = "SELECT COUNT(*) FROM notifications WHERE recipient_email = ? AND is_read = FALSE";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
```

---

### 5.5 Configuration Descriptor
`src/main/webapp/WEB-INF/web.xml`
```xml
<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee
                             http://xmlns.jcp.org/xml/ns/javaee/web-app_4_0.xsd"
         version="4.0">

    <display-name>CampusFix Web Application</display-name>

    <welcome-file-list>
        <welcome-file>index.jsp</welcome-file>
    </welcome-file-list>

    <!-- Spring Root Application Context -->
    <context-param>
        <param-name>contextClass</param-name>
        <param-value>org.springframework.web.context.support.AnnotationConfigWebApplicationContext</param-value>
    </context-param>
    <context-param>
        <param-name>contextConfigLocation</param-name>
        <param-value>com.campusfix.config.AppConfig</param-value>
    </context-param>

    <listener>
        <listener-class>org.springframework.web.context.ContextLoaderListener</listener-class>
    </listener>

    <!-- Spring DispatcherServlet -->
    <servlet>
        <servlet-name>dispatcher</servlet-name>
        <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
        <init-param>
            <param-name>contextClass</param-name>
            <param-value>org.springframework.web.context.support.AnnotationConfigWebApplicationContext</param-value>
        </init-param>
        <init-param>
            <param-name>contextConfigLocation</param-name>
            <param-value>com.campusfix.config.WebMvcConfig</param-value>
        </init-param>
        <load-on-startup>1</load-on-startup>
    </servlet>

    <servlet-mapping>
        <servlet-name>dispatcher</servlet-name>
        <url-pattern>/api/*</url-pattern>
    </servlet-mapping>

</web-app>
```

---

### 5.6 Interactive Client Logic
`src/main/webapp/js/main.js` (Excerpts for Notification Dropdown & CSV Export)
```javascript
// Live Notification Dropdown Loader
function toggleNotificationDropdown(event) {
    event.stopPropagation();
    const dropdown = document.getElementById('notifDropdown');
    if (!dropdown) return;

    dropdown.classList.toggle('show');
    if (dropdown.classList.contains('show')) {
        fetch('api/notifications')
            .then(res => res.json())
            .then(notifications => {
                const list = document.getElementById('notifDropdownList');
                if (!notifications || notifications.length === 0) {
                    list.innerHTML = '<div style="padding:16px; text-align:center; color:#94a3b8;">No notifications</div>';
                    return;
                }
                list.innerHTML = notifications.slice(0, 5).map(n => `
                    <div class="notif-item ${!n.read ? 'unread' : ''}">
                        <div style="font-weight:700; font-size:13px;">${n.title}</div>
                        <div style="font-size:12px; color:#64748b;">${n.message}</div>
                    </div>
                `).join('');
            })
            .catch(() => {});
    }
}

// Client-side CSV Table Export
function exportTableToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;

    let csv = [];
    const rows = table.querySelectorAll("tr");
    for (let i = 0; i < rows.length; i++) {
        let row = [], cols = rows[i].querySelectorAll("td, th");
        for (let j = 0; j < cols.length - 1; j++) {
            row.push('"' + cols[j].innerText.trim().replace(/"/g, '""') + '"');
        }
        csv.push(row.join(","));
    }

    const csvFile = new Blob([csv.join("\n")], { type: "text/csv" });
    const downloadLink = document.createElement("a");
    downloadLink.download = filename || "CampusFix_Export.csv";
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.click();
}
```

---

## 6. Project Verification & Execution Summary

1. **Compilation & Packaging:** Built with Apache Maven 3.9 using `mvn package -DskipTests`. Generates `c:\Users\tippa\intellij\CampusFix\target\CampusFix.war` with 0 errors.
2. **Local Deployment:** Run via IntelliJ IDEA Smart Tomcat mapped to `http://localhost:8080/CampusFix/`.
3. **Database Integration:** Automatically initializes `campusfix` tables (`complaints`, `feedback`, `notifications`) upon first server startup.
