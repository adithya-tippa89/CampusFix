# CampusFix - Campus Maintenance & Complaint Management System

**CampusFix** is a modern, full-stack college facility and infrastructure maintenance portal built with **Java EE (Servlet 4.0)**, **Spring Framework 5.3 (MVC, JDBC, Context)**, **MySQL**, and a responsive, animated UI design system.

---

## 🚀 Key Features

### 1. 📋 Smart Complaint Submission
- **Visual Category Picker**: 9 interactive category cards (Electrical, Plumbing, Wi-Fi, Furniture, AC, Laboratory, Sanitation, Civil, Security) with active state indicators.
- **Location Quick-Chips**: One-click pills to auto-populate common campus locations (Admin Block, Science Block, Central Library, Computer Labs, Hostels, Cafeteria).
- **Dynamic SLA Tracker**: Real-time resolution commitment badge showing expected turnaround time (High: 24h, Medium: 48h, Low: 72h).
- **Template Prompts**: Quick 1-click issue starter templates for fast drafting.
- **Character Counter**: Live client-side character countdown (0 / 500 max).
- **Contact Phone Input**: Direct callback number field for prompt technician coordination.
- **Photo Upload & Live Preview**: Drag-and-drop or file selector with instant thumbnail preview and remove capability.

### 2. 🔔 Real-Time Notification Center
- **Navbar Bell Badge**: Live unread count badge with animated ping.
- **Interactive Dropdown**: Quick preview of the 5 most recent notifications with direct action links.
- **Automated Event Triggers**:
  - Complaint created → Student confirmation + Admin alert.
  - Staff assigned → Technician notification + Student update.
  - Status changed (`IN PROGRESS`, `RESOLVED`) → Real-time student notification.
  - Review submitted → Notification to assigned staff.
- **Dedicated Inbox (`/notifications`)**: Full paginated notification history with unread filtering and "Mark all as read" capability.

### 3. ⭐ Student Feedback & Star Ratings
- Post-resolution 5-star rating modal with optional comments.
- Average rating calculation displayed directly on staff and admin dashboards.

### 4. 📊 Admin & Staff Dashboards
- **Admin**: Full campus overview, complaint assignment to technicians, priority management, analytics, CSV data export.
- **Staff**: Assigned work orders, status progression (`ASSIGNED` → `IN PROGRESS` → `RESOLVED`), student contact details.

### 5. 🏗️ Modern Spring Framework Integration
- **Layered Architecture**: Controller → Service → DAO pattern.
- **Spring REST APIs (`/api/*`)**:
  - `GET /api/complaints` - Query all complaints.
  - `GET /api/complaints/{id}` - Single complaint details.
  - `POST /api/complaints/add` - REST endpoint for complaint submission.
  - `GET /api/analytics/stats` - Summary statistics (total, pending, resolved, avg rating).
  - `GET /api/notifications` - User notification stream.
  - `GET /api/notifications/unread-count` - Badge counter endpoint.
- **Spring MVC Config**: `@ComponentScan`, static resource handler mapping, `ContextLoaderListener`, and `DispatcherServlet` integrated into `web.xml`.

---

## 🛠️ Technology Stack
- **Backend**: Java 8+, Servlet 4.0, Spring Framework 5.3.39 (spring-webmvc, spring-context, spring-jdbc), Jackson 2.17.2
- **Database**: MySQL 8.0 / MariaDB with automatic table initialization (`feedback`, `notifications`)
- **Server**: Apache Tomcat 9.0 (with Smart Tomcat plugin support in IntelliJ IDEA)
- **Frontend**: JSP, Vanilla JS (ES6+), FontAwesome 6, CSS3 Custom Properties (Design System with micro-animations)

---

## ⚙️ Setup & Running

### Prerequisites
1. **JDK**: Java 8, 11, 17, 21, or 26.
2. **Database**: MySQL running on `localhost:3306` with database `campusfix` created.
   ```sql
   CREATE DATABASE IF NOT EXISTS campusfix;
   ```
3. **Application Server**: Apache Tomcat 9.0.

### Running in IntelliJ IDEA
1. Open the project folder `CampusFix` in IntelliJ IDEA.
2. Ensure database credentials in `com.campusfix.util.DBConnection.java` match your MySQL setup:
   - URL: `jdbc:mysql://localhost:3306/campusfix`
   - Default Username: `root`
   - Default Password: `your_password`
3. Run with **Smart Tomcat**:
   - `Tomcat Server` -> select your local Tomcat 9 directory.
   - `Deployment Directory`: `src/main/webapp`
   - `Context Path`: `/CampusFix`
4. Access in browser:
   `http://localhost:8080/CampusFix/`

---

## 👥 Default Roles & Logins
- **Student**: Any registered student account (Register via `/register.jsp`)
- **Staff / Technician**: Accounts assigned role `STAFF`
- **Administrator**: Accounts assigned role `ADMIN`
